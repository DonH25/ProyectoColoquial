package co.edu.unbosque.model.persistence;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class GamesFile {

	private File gamesFile;
	private ObjectOutputStream oos;
	private String gameName;
	private String gameType;
	private double gameBudget;

	
	public GamesFile() {
		gamesFile = new File("data/juegos.dat");
		
	}
	
	public void createFile () {
		if (gamesFile.exists()) {
			System.out.println("El archivo ya existe");
		}else {
			try {
				gamesFile.createNewFile();
				System.out.println("Archivo creado exitosamente!");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public void writeFile(ArrayList<GamesDTO> games, File f1) {
		try {
			oos = new ObjectOutputStream(new FileOutputStream(f1));
			oos.writeObject(games);
			oos.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public ArrayList<GamesDTO> initializeFile() {
	    ArrayList<GamesDTO> g = new ArrayList<>();
	    try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(gamesFile))) {
	        Object obj = ois.readObject();
	        g = (ArrayList<GamesDTO>) obj;
	        System.out.println("Archivo");
	    } catch (FileNotFoundException e) {
	        e.printStackTrace();
	    } catch (IOException | ClassNotFoundException e) {
	        e.printStackTrace();
	    }
	    return g;
	}
	
	
	

	public File getGamesFile() {
		return gamesFile;
	}

	public void setGamesFile(File gamesFile) {
		this.gamesFile = gamesFile;
	}

	public String getGameName() {
		return gameName;
	}

	public void setGameName(String gameName) {
		this.gameName = gameName;
	}

	public String getGameType() {
		return gameType;
	}

	public void setGameType(String gameType) {
		this.gameType = gameType;
	}

	public double getGameBudget() {
		return gameBudget;
	}

	public void setGameBudget(double gameBudget) {
		this.gameBudget = gameBudget;
	}
	
	
	
	
	
}


