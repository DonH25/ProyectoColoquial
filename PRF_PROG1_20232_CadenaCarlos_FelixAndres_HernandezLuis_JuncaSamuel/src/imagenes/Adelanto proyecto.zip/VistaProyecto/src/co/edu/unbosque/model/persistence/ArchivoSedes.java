package co.edu.unbosque.model.persistence;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class ArchivoSedes {
	
	private File archivoSedes;
	private ObjectOutputStream oos;
	
	public ArchivoSedes() {
		archivoSedes = new File("data/sedes.dat");
	}
	
	public void crearArchivo () {
		if (archivoSedes.exists()) {
			System.out.println("El archivo ya existe");
		}else {
			try {
				archivoSedes.createNewFile();
				System.out.println("Archivo creado exitosamente!");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public void escribirArchivoSedes(ArrayList<SedesDTO> sedes) {
		try {
			oos = new ObjectOutputStream(new FileOutputStream(archivoSedes));
			oos.writeObject(sedes);
			oos.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public ArrayList<SedesDTO> initializeFile() {
	    ArrayList<SedesDTO> g = new ArrayList<>();
	    try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(archivoSedes))) {
	        Object obj = ois.readObject();
	        g = (ArrayList<SedesDTO>) obj;
	        System.out.println("Archivo");
	    } catch (FileNotFoundException e) {
	        e.printStackTrace();
	    } catch (IOException | ClassNotFoundException e) {
	        e.printStackTrace();
	    }
	    return g;
	}
	
}
