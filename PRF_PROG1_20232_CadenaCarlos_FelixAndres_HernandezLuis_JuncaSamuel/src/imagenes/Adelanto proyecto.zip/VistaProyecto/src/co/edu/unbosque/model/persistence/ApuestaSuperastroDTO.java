package co.edu.unbosque.model.persistence;

import java.io.Serializable;

public class ApuestaSuperastroDTO extends Apuesta implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int numeroApostado;
	private String signoZodiaco;
	
	public ApuestaSuperastroDTO(String nombreSede, long numCedula, String diaApuesta, double valorApuesta) {
		super(nombreSede, numCedula, diaApuesta, valorApuesta);
		// TODO Auto-generated constructor stub
	}

	public ApuestaSuperastroDTO(String nombreSede, long numCedula, String diaApuesta, double valorApuesta,
			int numeroApostado, String signoZodiaco) {
		super(nombreSede, numCedula, diaApuesta, valorApuesta);
		this.numeroApostado = numeroApostado;
		this.signoZodiaco = signoZodiaco;
	}
	
	public String toString() {
		return "Apuesta Superastro: "+"\n" + "Nombre sede: " + nombreSede + " Cedula: " + numCedula + " Dia apuesta: "
				+ diaApuesta + " Valor apuesta: " + valorApuesta + " Signo del zodiaco: " + signoZodiaco
				+" Número apostado: "+numeroApostado+"\n";
	}
	
	public int getNumeroApostado() {
		return numeroApostado;
	}

	public void setNumeroApostado(int numeroApostado) {
		this.numeroApostado = numeroApostado;
	}


	
	public String getSignoZodiaco() {
		return signoZodiaco;
	}

	public void setSignoZodiaco(String signoZodiaco) {
		this.signoZodiaco = signoZodiaco;
	}

	public String getNombreSede() {
		return nombreSede;
	}

	public void setNombreSede(String nombreSede) {
		this.nombreSede = nombreSede;
	}

	public long getNumCedula() {
		return numCedula;
	}

	public void setNumCedula(long numCedula) {
		this.numCedula = numCedula;
	}

	public String getDiaApuesta() {
		return diaApuesta;
	}

	public void setDiaApuesta(String diaApuesta) {
		this.diaApuesta = diaApuesta;
	}

	public double getValorApuesta() {
		return valorApuesta;
	}

	public void setValorApuesta(double valorApuesta) {
		this.valorApuesta = valorApuesta;
	}
	
	
	

}
