package co.edu.unbosque.model;

import co.edu.unbosque.model.persistence.ApuestaBetplayDAO;

public class ApuestaBetplay {

	private ApuestaBetplayDAO apuestaBetplay;

	public ApuestaBetplay() {
		apuestaBetplay = new ApuestaBetplayDAO();
	}

	public String crearApuestaBetplay(String nombreSede, long cedula, String diaApuesta, double valorApuesta,
			String partido1, String partido2, String partido3, String partido4, String partido5, String partido6,
			String partido7, String partido8, String partido9, String partido10, String partido11, String partido12,
			String partido13, String partido14) {

		return apuestaBetplay.crearApuestaBetplay(nombreSede, cedula, diaApuesta, valorApuesta, partido1, partido2,
				partido3, partido4, partido5, partido6, partido7, partido8, partido9, partido10, partido11, partido12,
				partido13, partido14);
	}

	public String modificarApuestaBetplay(String nombreSede, long cedula, String diaApuestaAnterior, String diaApuesta, double valorApuesta,
			String partido1, String partido2, String partido3, String partido4, String partido5, String partido6,
			String partido7, String partido8, String partido9, String partido10, String partido11, String partido12,
			String partido13, String partido14) {
		return apuestaBetplay.modificarApuestaBetplay(nombreSede, cedula, diaApuestaAnterior, diaApuesta, valorApuesta, partido1, partido2,
				partido3, partido4, partido5, partido6, partido7, partido8, partido9, partido10, partido11, partido12,
				partido13, partido14);
	}
	
	public String leerApuestaBetplay () {
		return apuestaBetplay.leerApuestas();
	}
	
	public String eliminarApuestaBetplay (long cedula, String diaApuesta) {
		return apuestaBetplay.eliminarApuestaBetplay(cedula, diaApuesta);
	}
	
	public void inicializarApuestasBetplay() {
		apuestaBetplay.inicializarApuestasBetplay();
	}

	public ApuestaBetplayDAO getApuestaBetplay() {
		return apuestaBetplay;
	}

	public void setApuestaBetplay(ApuestaBetplayDAO apuestaBetplay) {
		this.apuestaBetplay = apuestaBetplay;
	}
	
	
}
