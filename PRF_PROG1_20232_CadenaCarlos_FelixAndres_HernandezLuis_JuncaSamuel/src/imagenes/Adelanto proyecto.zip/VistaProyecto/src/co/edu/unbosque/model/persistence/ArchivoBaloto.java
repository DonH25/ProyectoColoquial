package co.edu.unbosque.model.persistence;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class ArchivoBaloto {
	
	private File fileApuesta;
	private ObjectOutputStream oos;
	
	public ArchivoBaloto() {
		fileApuesta = new File("data/apuestas-baloto.dat");
		
	}


	public void crearArchivo() {
		if(!fileApuesta.exists()) {
		try {
			fileApuesta.createNewFile();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}else {
			System.out.println("El archivo ya existe");
		}
		
	}

	public void escribirArchivo(ArrayList<ApuestaBalotoDTO> bal) {
		try {
			oos = new ObjectOutputStream(new FileOutputStream(fileApuesta));
			oos.writeObject(bal);
			oos.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	
	public ArrayList<ApuestaBalotoDTO> inicializarArchivo() {
		
		    ArrayList<ApuestaBalotoDTO> apuesta = new ArrayList<>();
		    try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fileApuesta))) {
		        Object obj = ois.readObject();
		        apuesta = (ArrayList<ApuestaBalotoDTO>) obj;
		        System.out.println("Archivo");
		    } catch (FileNotFoundException e) {
		        e.printStackTrace();
		    } catch (IOException | ClassNotFoundException e) {
		        e.printStackTrace();
		    }
		    return apuesta;
		
		
	}
}
