package co.edu.unbosque.view;

import javax.swing.JOptionPane;

public class Aviso {

	public Aviso() {

	}

	public void mostrarInfo(String dato) {
		JOptionPane.showMessageDialog(null, dato, "Aviso", JOptionPane.INFORMATION_MESSAGE);
	}
	
	public String recibirInfo(String info) {
		return JOptionPane.showInputDialog(info);
	}
}
