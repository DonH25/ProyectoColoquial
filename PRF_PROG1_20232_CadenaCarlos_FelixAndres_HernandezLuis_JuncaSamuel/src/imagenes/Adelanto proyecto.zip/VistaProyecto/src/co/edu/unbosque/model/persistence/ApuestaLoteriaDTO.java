package co.edu.unbosque.model.persistence;

import java.io.Serializable;

public class ApuestaLoteriaDTO extends Apuesta implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String nombreLoteria;
	private int numeroApostado;
	private int serieLoteria;

	public ApuestaLoteriaDTO(String nombreSede, long numCedula, String diaApuesta, double valorApuesta) {
		super(nombreSede, numCedula, diaApuesta, valorApuesta);
		// TODO Auto-generated constructor stub
	}

	public ApuestaLoteriaDTO(String nombreSede, long numCedula, String diaApuesta, double valorApuesta,
			String nombreLoteria, int numeroApostado, int serieLoteria) {
		super(nombreSede, numCedula, diaApuesta, valorApuesta);
		this.nombreLoteria = nombreLoteria;
		this.numeroApostado = numeroApostado;
		this.serieLoteria = serieLoteria;
	}

	public String toString() {
		return "Apuesta Loteria: " + "Nombre sede: " + nombreSede + " Cedula: " + numCedula + " Dia apuesta: "
				+ diaApuesta + " Valor apuesta: " + valorApuesta + " Nombre loteria: " + nombreLoteria
				+ " Numero loteria: " + numeroApostado + " Numero serie: " + serieLoteria+ "\n";
	}

	public String getNombreSede() {
		return nombreSede;
	}

	public void setNombreSede(String nombreSede) {
		this.nombreSede = nombreSede;
	}

	public long getNumCedula() {
		return numCedula;
	}

	public void setNumCedula(long numCedula) {
		this.numCedula = numCedula;
	}

	public String getDiaApuesta() {
		return diaApuesta;
	}

	public void setDiaApuesta(String diaApuesta) {
		this.diaApuesta = diaApuesta;
	}

	public double getValorApuesta() {
		return valorApuesta;
	}

	public void setValorApuesta(double valorApuesta) {
		this.valorApuesta = valorApuesta;
	}

	public String getNombreLoteria() {
		return nombreLoteria;
	}

	public void setNombreLoteria(String nombreLoteria) {
		this.nombreLoteria = nombreLoteria;
	}

	public int getNumeroApostado() {
		return numeroApostado;
	}

	public void setNumeroApostado(int numeroApostado) {
		this.numeroApostado = numeroApostado;
	}

	public int getSerieLoteria() {
		return serieLoteria;
	}

	public void setSerieLoteria(int serieLoteria) {
		this.serieLoteria = serieLoteria;
	}

}
