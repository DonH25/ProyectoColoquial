package co.edu.unbosque.model.persistence;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class BHProperties {
	
	private Properties prop;
	private String route;
	private String bettingHouseName;
	private String numberOfSites;
	private String totalBudget;
	
	public BHProperties() {
		prop = new Properties();
		route = "data/config.properties";
	}
	
	public int writeProperties(String houseName, String numberOfSites, String totalBudget) {
	try {
		prop.setProperty("bettingHouseName", houseName);
		prop.setProperty("numberOfSites", numberOfSites);
		prop.setProperty("totalBudget", totalBudget);
		prop.store(new FileOutputStream(route), null);
	} 
	catch (IOException ex) {
		return -1;
	}
	return 0;
}

public int modifyProperties(String houseName, String numberOfSites, String totalBudget) {
	try {
		prop.load(new FileInputStream(route));
		prop.setProperty("bettingHouseName", houseName);
		prop.setProperty("numberOfSites", numberOfSites);
		prop.setProperty("totalBudget", totalBudget);
		prop.store(new FileOutputStream (route), null);
	} catch (FileNotFoundException e) {
		e.printStackTrace();
		return -1;
	} catch (IOException e) {
		e.printStackTrace();
		return -1;
	}
	return 0;
}

public int initializeProperties() {
	try {
		prop.load(new FileInputStream(route));
		bettingHouseName = prop.getProperty("bettingHouseName");
		numberOfSites = prop.getProperty("numberOfSites");
		totalBudget = prop.getProperty("totalBudget");
	} catch (FileNotFoundException e) {
		e.printStackTrace();
		return -1;
	} catch (IOException e) {
		e.printStackTrace();
		return -1;
	}
	return 0;
}

public String getBettingHouseName() {
	return bettingHouseName;
}

public void setBettingHouseName(String bettingHouseName) {
	this.bettingHouseName = bettingHouseName;
}

public String getNumberOfSites() {
	return numberOfSites;
}

public void setNumberOfSites(String numberOfSites) {
	this.numberOfSites = numberOfSites;
}

public String getTotalBudget() {
	return totalBudget;
}

public void setTotalBudget(String totalBudget) {
	this.totalBudget = totalBudget;
}


}
