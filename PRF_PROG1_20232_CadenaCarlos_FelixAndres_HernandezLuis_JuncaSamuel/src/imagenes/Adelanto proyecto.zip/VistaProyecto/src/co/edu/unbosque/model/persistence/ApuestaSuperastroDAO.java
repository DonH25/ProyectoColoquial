package co.edu.unbosque.model.persistence;

import java.io.File;
import java.util.ArrayList;

public class ApuestaSuperastroDAO {
	private ArrayList<ApuestaSuperastroDTO> apuestasSuperastro;
	private ArchivoSuperastro archivoSuperastro;

	public ApuestaSuperastroDAO() {
		apuestasSuperastro = new ArrayList<ApuestaSuperastroDTO>();
		archivoSuperastro = new ArchivoSuperastro();
	}

	public void crearApuestaSuperastro(String nombreSede, long cedula, String diaApuesta, double valorApuesta,
			String signoZodiaco, int numeroApostado) {

		apuestasSuperastro.add(new ApuestaSuperastroDTO(nombreSede, cedula, diaApuesta, valorApuesta, numeroApostado, signoZodiaco));
		archivoSuperastro.crearArchivo();
		archivoSuperastro.escribirArchivo(apuestasSuperastro);
		System.out.println("Apuesta realizada correctamente");
	}

	public void modificarApuestaSuperastro(String nombreSede, long cedula, String diaApuesta, int anteriorNumeroApostado,
			double nuevoValorApuesta, String nuevoSignoZodiaco, int nuevoNumeroApostado) {

		for (int i = 0; i < apuestasSuperastro.size(); i++) {
			if (cedula == apuestasSuperastro.get(i).getNumCedula()
					&& anteriorNumeroApostado == apuestasSuperastro.get(i).getNumeroApostado()) {
				apuestasSuperastro.set(i, new ApuestaSuperastroDTO(nombreSede, cedula, diaApuesta, nuevoValorApuesta, nuevoNumeroApostado, nuevoSignoZodiaco));
			}
			File tmp = new File("data/apuestas-superastro.dat");
			tmp.delete();
			archivoSuperastro.crearArchivo();
			archivoSuperastro.escribirArchivo(apuestasSuperastro);
		}
	}

	public String leerApuestas() {
		String printable = "";
		for (ApuestaSuperastroDTO apuestaSuperastroDTO : apuestasSuperastro) {
			printable += apuestaSuperastroDTO.toString();
		}
		return printable;
	}
	
	public void eliminarApuestaSuperastro( long cedula, int numeroApostado) {
		for (int i = 0; i < apuestasSuperastro.size(); i++) {
			if (cedula == apuestasSuperastro.get(i).getNumCedula()
					&& numeroApostado == apuestasSuperastro.get(i).getNumeroApostado()) {
				apuestasSuperastro.remove(i);
			}
		}
		File tmp = new File("data/apuestas-superastro.dat");
		tmp.delete();
		archivoSuperastro.crearArchivo();
		archivoSuperastro.escribirArchivo(apuestasSuperastro);
	}
	
	public void inicializarApuestasSuperastro(){
		apuestasSuperastro = archivoSuperastro.inicializarArchivo();
	}

	public ArrayList<ApuestaSuperastroDTO> getApuestasSuperastro() {
		return apuestasSuperastro;
	}

	public void setApuestasSuperastro(ArrayList<ApuestaSuperastroDTO> apuestasSuperastro) {
		this.apuestasSuperastro = apuestasSuperastro;
	}
	
	
}
