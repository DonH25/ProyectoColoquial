package co.edu.unbosque.model;

import co.edu.unbosque.model.persistence.ApostadorDAO;
import co.edu.unbosque.model.persistence.ApostadorDTO;

public class GestionApostador {

	private ApostadorDAO apostador;

	public GestionApostador() {
		apostador = new ApostadorDAO();
	}

	public void crearApostador(String nombre, long cedula, String sede, String direccion, long numCelular) {
		apostador.create(new ApostadorDTO(nombre, cedula, sede, direccion, numCelular));
	}

	public void modificarApostador(String nombreAModificar, String nuevoNombre, long nuevaCedula, String nuevaSede,
			String nuevaDireccion, long nuevoNumCelular) {
		apostador.modify(nombreAModificar, nuevoNombre, nuevaCedula, nuevaSede, nuevaDireccion, nuevoNumCelular);
	}

	public String leerApostadores() {
		return apostador.readAll();
	}
	
	public void eliminarApostador(long numCedula) {
		apostador.delete(numCedula);
	}

	public void inicializarApostadores() {
		apostador.initializeFile();
	}

	public ApostadorDAO getApostador() {
		return apostador;
	}

	public void setApostador(ApostadorDAO apostador) {
		this.apostador = apostador;
	}
	
	
}
