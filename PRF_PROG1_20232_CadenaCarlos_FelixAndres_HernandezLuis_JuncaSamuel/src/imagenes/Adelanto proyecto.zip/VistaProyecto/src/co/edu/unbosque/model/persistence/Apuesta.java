package co.edu.unbosque.model.persistence;

import java.io.Serializable;

public abstract class Apuesta implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected String nombreSede;
	protected long numCedula;
	protected String diaApuesta;
	protected double valorApuesta;
	public Apuesta(String nombreSede, long numCedula, String diaApuesta, double valorApuesta) {
		super();
		this.nombreSede = nombreSede;
		this.numCedula = numCedula;
		this.diaApuesta = diaApuesta;
		this.valorApuesta = valorApuesta;
	}
	
	
	
	
	
}
