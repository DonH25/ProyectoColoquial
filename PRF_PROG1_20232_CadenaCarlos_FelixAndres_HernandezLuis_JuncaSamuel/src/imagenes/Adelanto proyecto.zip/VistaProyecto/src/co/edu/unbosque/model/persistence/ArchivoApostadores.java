package co.edu.unbosque.model.persistence;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class ArchivoApostadores {
	private File fileApostadores;
	private ObjectOutputStream oos;
	
	public ArchivoApostadores() {
		fileApostadores = new File("data/apostadores.dat");
		
	}

	
	public void crearArchivo () {
		if (fileApostadores.exists()) {
			System.out.println("El archivo ya existe");
		}else {
			try {
				fileApostadores.createNewFile();
				System.out.println("Archivo creado exitosamente!");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public void escribirArchivoApostador(ArrayList<ApostadorDTO> sedes) {
		try {
			oos = new ObjectOutputStream(new FileOutputStream(fileApostadores));
			oos.writeObject(sedes);
			oos.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
	public ArrayList<ApostadorDTO> initializeFile() {
	    ArrayList<ApostadorDTO> g = new ArrayList<>();
	    try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fileApostadores))) {
	        Object obj = ois.readObject();
	        g = (ArrayList<ApostadorDTO>) obj;
	        System.out.println("Archivo");
	    } catch (FileNotFoundException e) {
	        e.printStackTrace();
	    } catch (IOException | ClassNotFoundException e) {
	        e.printStackTrace();
	    }
	    return g;
	}

}
