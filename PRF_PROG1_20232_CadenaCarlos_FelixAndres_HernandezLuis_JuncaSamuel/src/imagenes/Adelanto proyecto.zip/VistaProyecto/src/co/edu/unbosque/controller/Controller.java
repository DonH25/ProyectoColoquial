package co.edu.unbosque.controller;

import java.awt.event.ActionListener;
import java.io.File;
import java.awt.event.ActionEvent;

import co.edu.unbosque.model.ApuestaBaloto;
import co.edu.unbosque.model.ApuestaBetplay;
import co.edu.unbosque.model.ApuestaChance;
import co.edu.unbosque.model.ApuestaLoteria;
import co.edu.unbosque.model.ApuestaSuperastro;
import co.edu.unbosque.model.BettingHouse;
import co.edu.unbosque.model.DataException;
import co.edu.unbosque.model.GamesData;
import co.edu.unbosque.model.GestionApostador;
import co.edu.unbosque.model.GestionSedes;
import co.edu.unbosque.view.Aviso;
import co.edu.unbosque.view.VentanaApostador;
import co.edu.unbosque.view.VentanaBaloto;
import co.edu.unbosque.view.VentanaBetPlay;
import co.edu.unbosque.view.VentanaChance;
import co.edu.unbosque.view.VentanaEleccion;
import co.edu.unbosque.view.VentanaLoteria;
import co.edu.unbosque.view.VentanaPresupuestos;
import co.edu.unbosque.view.VentanaPrincipal;
import co.edu.unbosque.view.VentanaRegistrar;
import co.edu.unbosque.view.VentanaSedes;
import co.edu.unbosque.view.VentanaSuperastro;

public class Controller implements ActionListener {

	private VentanaPrincipal vp;
	private VentanaRegistrar vr;
	private VentanaPresupuestos vPre;
	private VentanaSedes vs;
	private VentanaEleccion ve;
	private VentanaApostador va;
	private BettingHouse casaApuestas;
	private GamesData dataJuegos;
	private GestionSedes dataSedes;
	private GestionApostador dataApostador;
	private File temp, temp2, temp3, temp4, temp5, temp6, temp7, temp8, temp9;
	private Aviso aviso;
	private int eleccion;
	private VentanaLoteria vl;
	private VentanaBaloto vb;
	private VentanaSuperastro vsa;
	private VentanaBetPlay vbp;
	private VentanaChance vc;
	private ApuestaBaloto ab;
	private ApuestaLoteria al;
	private ApuestaSuperastro as;
	private ApuestaBetplay abp;
	private ApuestaChance ac;
	private String cedula, numApostado;

	public Controller() {
		// TODO Auto-generated constructor stub
		casaApuestas = new BettingHouse();
		dataJuegos = new GamesData();
		dataSedes = new GestionSedes();
		dataApostador = new GestionApostador();
		al = new ApuestaLoteria();
		ab = new ApuestaBaloto();
		as = new ApuestaSuperastro();
		abp = new ApuestaBetplay();
		ac = new ApuestaChance();
		temp = new File("data/config.properties");
		temp2 = new File("data/juegos.dat");
		temp3 = new File("data/sedes.dat");
		temp4 = new File("data/apostadores.dat");
		temp5 = new File("data/apuestas-loteria.dat");
		temp6 = new File("data/apuestas-baloto.dat");
		temp7 = new File("data/apuestas-superastro.dat");
		temp8 = new File("data/apuestas-betplay.dat");
		temp9 = new File("data/apuestas-chance.dat");
		aviso = new Aviso();
		va = new VentanaApostador();
		vp = new VentanaPrincipal();
		vr = new VentanaRegistrar();
		vPre = new VentanaPresupuestos();
		vs = new VentanaSedes();
		ve = new VentanaEleccion();
		vl = new VentanaLoteria();
		vb = new VentanaBaloto();
		vsa = new VentanaSuperastro();
		vbp = new VentanaBetPlay();
		vc = new VentanaChance();
		agregarLectores();
		eleccion = 0;
		cedula = "";
		numApostado = "";
	}

	public void ejecutar() {

		if (temp.exists() && temp2.exists() && temp3.exists()) {
			ve.setVisible(true);
			casaApuestas.initializeBettingHouseData();
			dataJuegos.initializeGames();
			dataSedes.inicializarSedes();
			ve.getBotonApostadores().setBounds(605, 225, 290, 180);
			System.out.println(dataJuegos.getGame().getGames().get(0).getGameBudget());
			System.out.println(dataJuegos.getGame().getGames().get(1).getGameBudget());
			System.out.println(dataJuegos.getGame().getGames().get(2).getGameBudget());
			System.out.println(dataJuegos.getGame().getGames().get(3).getGameBudget());
			System.out.println(dataJuegos.getGame().getGames().get(4).getGameBudget());
			System.out.println(casaApuestas.getHouse().getBettingHouse().getTotalBudget());

		} else {
			vp.setVisible(true);
		}

		if (temp4.exists()) {
			dataApostador.inicializarApostadores();
			System.out.println(dataApostador.leerApostadores());
			ve.getBotonApostador().setVisible(true);
			ve.getBotonCasaApuestas().setVisible(true);
			ve.getBotonModificar().setVisible(false);
			ve.getBotonApostadores().setVisible(false);

		}

		if (temp5.exists()) {
			al.inicializarApuestasLoteria();
		}
		if (temp6.exists()) {
			ab.inicializarApuestasBaloto();
		}
		if (temp7.exists()) {
			as.inicializarApuestasSuperastro();
		}
		if (temp8.exists()) {
			abp.inicializarApuestasBetplay();
		}
		if (temp9.exists()) {
			ac.inicializarApuestasChance();
		}

	}

	public void agregarLectores() {
		vp.getBotonIniciar().addActionListener(this);
		vp.getBotonIniciar().setActionCommand("BotonIniciarClick");
		vp.getBotonRegresar().addActionListener(this);
		vp.getBotonRegresar().setActionCommand("BotonSalirClick");
		vr.getFlecha().addActionListener(this);
		vr.getFlecha().setActionCommand("BotonRRClick");
		vr.getBotonCrear().addActionListener(this);
		vr.getBotonCrear().setActionCommand("btnCrearDataCasa");
		vPre.getBotonPresupuestos().addActionListener(this);
		vPre.getBotonPresupuestos().setActionCommand("BotonRPresupuestos");
		vs.getBotonSedes().addActionListener(this);
		vs.getBotonSedes().setActionCommand("BotonCrearSede");
		ve.getBotonModificar().addActionListener(this);
		ve.getBotonModificar().setActionCommand("BotonModificar");
		ve.getBotonApostadores().addActionListener(this);
		ve.getBotonApostadores().setActionCommand("BotonVentanaApostadores");
		vr.getBotonModificar().addActionListener(this);
		vr.getBotonModificar().setActionCommand("BotonModificarCasa");
		vPre.getBotonModificar().addActionListener(this);
		vPre.getBotonModificar().setActionCommand("BotonModificarJuegos");
		vs.getBotonModificarSedes().addActionListener(this);
		vs.getBotonModificarSedes().setActionCommand("BotonModificarSedes");
		vs.getBotonFinalizar().addActionListener(this);
		vs.getBotonFinalizar().setActionCommand("BotonFinalizar");
		vs.getBotonEliminarSede().addActionListener(this);
		vs.getBotonEliminarSede().setActionCommand("BotonEliminarSede");
		vs.getBotonLlenarSedes().addActionListener(this);
		vs.getBotonLlenarSedes().setActionCommand("BotonLlenarSedes");
		va.getBotonCrear().addActionListener(this);
		va.getBotonCrear().setActionCommand("BotonCrearApostador");
		ve.getBotonApostador().addActionListener(this);
		ve.getBotonApostador().setActionCommand("BotonSoyApostador");
		ve.getBotonCasaApuestas().addActionListener(this);
		ve.getBotonCasaApuestas().setActionCommand("BotonSoyCasaApuestas");
		ve.getBotonLeerApostador().addActionListener(this);
		ve.getBotonLeerApostador().setActionCommand("BotonLeerApostador");
		ve.getBotonModificarApostador().addActionListener(this);
		ve.getBotonModificarApostador().setActionCommand("BotonModificarApostador");
		ve.getBotonEliminarApostador().addActionListener(this);
		ve.getBotonEliminarApostador().setActionCommand("BotonEliminarApostador");
		va.getBotonModificar().addActionListener(this);
		va.getBotonModificar().setActionCommand("BtnModificarApostador");
		va.getBotonEliminar().addActionListener(this);
		va.getBotonEliminar().setActionCommand("BtnEliminarApostador");
		ve.getBotonApuesta().addActionListener(this);
		ve.getBotonApuesta().setActionCommand("BotonApuestas");
		ve.getBotonReportes().addActionListener(this);
		ve.getBotonReportes().setActionCommand("BotonReportes");
		ve.getFlecha().addActionListener(this);
		ve.getFlecha().setActionCommand("BotonRegresar");
		va.getFlecha().addActionListener(this);
		va.getFlecha().setActionCommand("BotonRegresarApostadores");
		ve.getBotonCrearApuesta().addActionListener(this);
		ve.getBotonCrearApuesta().setActionCommand("BotonRealizarApuesta");
		ve.getBotonModificarApuesta().addActionListener(this);
		ve.getBotonModificarApuesta().setActionCommand("BotonModificarApuesta");
		ve.getBotonEliminarApuestas().addActionListener(this);
		ve.getBotonEliminarApuestas().setActionCommand("BotonEliminarApuesta");
		ve.getBotonLeerApuestas().addActionListener(this);
		ve.getBotonLeerApuestas().setActionCommand("BotonLeerApuesta");
		ve.getFlecha2().addActionListener(this);
		ve.getFlecha2().setActionCommand("BotonRegresarApuestas");
		ve.getFlecha3().addActionListener(this);
		ve.getFlecha3().setActionCommand("BotonRegresarJuegos");
		ve.getBotonBaloto().addActionListener(this);
		ve.getBotonBaloto().setActionCommand("BotonApostarBaloto");
		ve.getBotonLoteria().addActionListener(this);
		ve.getBotonLoteria().setActionCommand("BotonApostarLoteria");
		ve.getBotonSuperastro().addActionListener(this);
		ve.getBotonSuperastro().setActionCommand("BotonApostarSuperastro");
		ve.getBotonBetplay().addActionListener(this);
		ve.getBotonBetplay().setActionCommand("BotonApostarBetplay");
		ve.getBotonChance().addActionListener(this);
		ve.getBotonChance().setActionCommand("BotonApostarChance");
		vl.getBotonApostar().addActionListener(this);
		vl.getBotonApostar().setActionCommand("btnApostarLoteria");
		vl.getBotonModificar().addActionListener(this);
		vl.getBotonModificar().setActionCommand("btnModificarLoteria");
		vl.getBotonEliminar().addActionListener(this);
		vl.getBotonEliminar().setActionCommand("btnEliminarLoteria");

		vb.getBotonApostar().addActionListener(this);
		vb.getBotonApostar().setActionCommand("btnApostarBaloto");
		vb.getBotonModificar().addActionListener(this);
		vb.getBotonModificar().setActionCommand("btnModificarBaloto");
		vb.getBotonEliminar().addActionListener(this);
		vb.getBotonEliminar().setActionCommand("btnEliminarBaloto");

		vsa.getBotonApostar().addActionListener(this);
		vsa.getBotonApostar().setActionCommand("btnApostarSuperastro");
		vsa.getBotonModificar().addActionListener(this);
		vsa.getBotonModificar().setActionCommand("btnModificarSuperastro");
		vsa.getBotonEliminar().addActionListener(this);
		vsa.getBotonEliminar().setActionCommand("btnEliminarSuperastro");

		vbp.getBotonApostar().addActionListener(this);
		vbp.getBotonApostar().setActionCommand("btnApostarBetplay");
		vbp.getBotonModificar().addActionListener(this);
		vbp.getBotonModificar().setActionCommand("btnModificarBetplay");
		vbp.getBotonEliminar().addActionListener(this);
		vbp.getBotonEliminar().setActionCommand("btnEliminarBetplay");

		vc.getBotonApostar().addActionListener(this);
		vc.getBotonApostar().setActionCommand("btnApostarChance");
		vc.getBotonModificar().addActionListener(this);
		vc.getBotonModificar().setActionCommand("btnModificarChance");
		vc.getBotonEliminar().addActionListener(this);
		vc.getBotonEliminar().setActionCommand("btnEliminarChance");
		
		vl.getFlecha().addActionListener(this);
		vl.getFlecha().setActionCommand("botonFlechaLoteria");
		vb.getFlecha().addActionListener(this);
		vb.getFlecha().setActionCommand("botonFlechaBaloto");
		vsa.getFlecha().addActionListener(this);
		vsa.getFlecha().setActionCommand("botonFlechaSuperastro");
		vbp.getFlecha().addActionListener(this);
		vbp.getFlecha().setActionCommand("botonFlechaBetplay");
		vc.getFlecha().addActionListener(this);
		vc.getFlecha().setActionCommand("botonFlechaChance");

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

		switch (e.getActionCommand()) {
		case "BotonIniciarClick": {

			vp.setVisible(false);
			vr.setVisible(true);

			break;

		}

		case "BotonSalirClick": {
			vp.setVisible(false);
			System.exit(0);
			break;
		}

		case "BotonRRClick": {
			vr.setVisible(false);
			vp.setVisible(true);

			break;

		}
		case "btnCrearDataCasa": {
			if (!vr.getNombreCasaField().getText().equals("") && !vr.getCantidadSedesField().getText().equals("")
					&& !vr.getPresupuestoTotalField().getText().equals("")) {
				boolean temp1 = true;

				try {
					Integer.parseInt(vr.getCantidadSedesField().getText());

				} catch (NumberFormatException ex) {
					ex.printStackTrace();
					temp1 = false;
					aviso.mostrarInfo("Debe ingresar valores validos.");
				}

				try {
					Double.parseDouble(vr.getPresupuestoTotalField().getText());

				} catch (NumberFormatException ex) {
					ex.printStackTrace();
					temp1 = false;
					aviso.mostrarInfo("Debe ingresar valores validos.");
				}

				try {
					if (vr.getNombreCasaField().getText().equals("") && vr.getCantidadSedesField().getText().equals("")
							&& vr.getPresupuestoTotalField().getText().equals("")) {
						throw new DataException("Debe ingresar valores en los campos");
					}
				} catch (DataException ex) {
					aviso.mostrarInfo("Debe ingresar valores en los campos");
					temp1 = false;
				}
				System.out.println(temp1);
				if ((temp1 == true)) {
					casaApuestas.fillBettingHouseData(vr.getNombreCasaField().getText(),
							vr.getCantidadSedesField().getText(), vr.getPresupuestoTotalField().getText());
					casaApuestas.initializeBettingHouseData();
					aviso.mostrarInfo("Datos ingresados correctamente");
					vPre.setVisible(true);
					vr.setVisible(false);

				} else {

				}

			} else {
				aviso.mostrarInfo("Debe llenar todos los datos para crear la casa de apuestas");
			}

			break;
		}

		case "BotonRPresupuestos": {
			if (!vPre.getpLoteria().getText().equals("") && !vPre.getpBaloto().getText().equals("")
					&& !vPre.getpSuperastro().getText().equals("") && !vPre.getpBetplay().getText().equals("")
					&& !vPre.getpChance().getText().equals("")) {

				boolean temp1 = true;

				try {
					Double.parseDouble(vPre.getpLoteria().getText());

				} catch (NumberFormatException ex) {
					ex.printStackTrace();
					temp1 = false;
					aviso.mostrarInfo("Debe ingresar valores validos.");
				}
				try {
					Double.parseDouble(vPre.getpBaloto().getText());

				} catch (NumberFormatException ex) {
					ex.printStackTrace();
					temp1 = false;
					aviso.mostrarInfo("Debe ingresar valores validos.");
				}
				try {
					Double.parseDouble(vPre.getpSuperastro().getText());

				} catch (NumberFormatException ex) {
					ex.printStackTrace();
					temp1 = false;
					aviso.mostrarInfo("Debe ingresar valores validos.");
				}
				try {
					Double.parseDouble(vPre.getpBetplay().getText());

				} catch (NumberFormatException ex) {
					ex.printStackTrace();
					temp1 = false;
					aviso.mostrarInfo("Debe ingresar valores validos.");
				}
				try {
					Double.parseDouble(vPre.getpChance().getText());

				} catch (NumberFormatException ex) {
					ex.printStackTrace();
					temp1 = false;
					aviso.mostrarInfo("Debe ingresar valores validos.");
				}

				if (temp1 == true) {
					casaApuestas.initializeBettingHouseData();
					double tmp1 = Double.parseDouble(vPre.getpLoteria().getText());
					double tmp2 = Double.parseDouble(vPre.getpBaloto().getText());
					double tmp3 = Double.parseDouble(vPre.getpSuperastro().getText());
					double tmp4 = Double.parseDouble(vPre.getpBetplay().getText());
					double tmp5 = Double.parseDouble(vPre.getpChance().getText());

					double sumPresupuesto = tmp1 + tmp2 + tmp3 + tmp4 + tmp5;

					if (sumPresupuesto <= Double.parseDouble(vr.getPresupuestoTotalField().getText())) {
						dataJuegos.createGames("Loteria", "Loteria", vPre.getpLoteria().getText());
						dataJuegos.createGames("Baloto", "Loteria", vPre.getpBaloto().getText());
						dataJuegos.createGames("SuperAstro", "Loteria", vPre.getpSuperastro().getText());
						dataJuegos.createGames("BetPlay", "Deportivo", vPre.getpBetplay().getText());
						dataJuegos.createGames("Chance", "Chance", vPre.getpChance().getText());

						aviso.mostrarInfo("Información de juegos guardada correctamente");
						vPre.setVisible(false);
						vs.setVisible(true);
					} else {
						aviso.mostrarInfo(
								"La suma de los presupuestos excede su presupuesto total, realice de nuevo la distribución del presupuesto");
					}
				}
			} else {
				aviso.mostrarInfo("Debe completar todos los campos.");
			}
			break;

		}
		case "BotonCrearSede": {
			if (!vs.getLocalidadField().getText().equals("") && !vs.getEmpleadosField().getText().equals("")) {
				boolean tmp = true;
				try {
					Integer.parseInt(vs.getEmpleadosField().getText());
				} catch (NumberFormatException ex) {
					tmp = false;
					aviso.mostrarInfo("Ingrese un número valido");
					ex.printStackTrace();
				}

				if (tmp == true) {
					casaApuestas.initializeBettingHouseData();
					aviso.mostrarInfo(dataSedes.crearNuevaSede(
							casaApuestas.getHouse().getBettingHouse().getNumberOfSites(),
							vs.getLocalidadField().getText(), Integer.parseInt(vs.getEmpleadosField().getText())));
					if (casaApuestas.getHouse().getBettingHouse().getNumberOfSites() == dataSedes.getSedes().getSedes()
							.size()) {

						aviso.mostrarInfo("Archivo de sedes creado exitosamente");
						ve.setVisible(true);
						vs.setVisible(false);
						ve.getBotonApostadores().setBounds(605, 225, 290, 180);
					} else {

						vs.getLocalidadField().setText(null);
						vs.getEmpleadosField().setText(null);
					}

				}

			} else {
				aviso.mostrarInfo("Debe llenar todos los campos");
			}
			break;
		}
		case "BotonModificar": {
			vr.setVisible(true);
			ve.setVisible(false);
			vr.getBotonCrear().setVisible(false);
			vr.getBotonModificar().setVisible(true);
			aviso.mostrarInfo(
					"A continuación, modifica los datos que desees, en caso de que no se necesite cambiar nada, deja los campos llenos y continua.");
			vr.getNombreCasaField().setText(casaApuestas.getHouse().getBettingHouse().getBettingHouseName());
			vr.getCantidadSedesField()
					.setText(String.valueOf(casaApuestas.getHouse().getBettingHouse().getNumberOfSites()));
			vr.getPresupuestoTotalField()
					.setText(String.valueOf(casaApuestas.getHouse().getBettingHouse().getTotalBudget()));
			break;
		}
		case "BotonModificarCasa": {
			if (!vr.getNombreCasaField().getText().equals("") && !vr.getCantidadSedesField().getText().equals("")
					&& !vr.getPresupuestoTotalField().getText().equals("")) {
				boolean temp1 = true;

				try {
					Integer.parseInt(vr.getCantidadSedesField().getText());

				} catch (NumberFormatException ex) {
					ex.printStackTrace();
					temp1 = false;
					aviso.mostrarInfo("Debe ingresar valores validos.");
				}

				try {
					Double.parseDouble(vr.getPresupuestoTotalField().getText());

				} catch (NumberFormatException ex) {
					ex.printStackTrace();
					temp1 = false;
					aviso.mostrarInfo("Debe ingresar valores validos.");
				}

				try {
					if (vr.getNombreCasaField().getText().equals("") && vr.getCantidadSedesField().getText().equals("")
							&& vr.getPresupuestoTotalField().getText().equals("")) {
						throw new DataException("Debe ingresar valores en los campos");
					}
				} catch (DataException ex) {
					aviso.mostrarInfo("Debe ingresar valores en los campos");
					temp1 = false;
				}
				System.out.println(temp1);
				if ((temp1 == true)) {
					casaApuestas.modifyBettingHouseData(vr.getNombreCasaField().getText(),
							vr.getCantidadSedesField().getText(), vr.getPresupuestoTotalField().getText());
					casaApuestas.initializeBettingHouseData();
					aviso.mostrarInfo("Datos modificados correctamente");
					vPre.setVisible(true);
					vPre.getBotonModificar().setVisible(true);
					vPre.getBotonPresupuestos().setVisible(false);
					vr.setVisible(false);
					casaApuestas.initializeBettingHouseData();
					String salida1 = "" + dataJuegos.getGame().getGames().get(0).getGameBudget();
					System.out.println(salida1);
					String salida2 = "" + dataJuegos.getGame().getGames().get(1).getGameBudget();
					System.out.println(salida2);
					String salida3 = "" + dataJuegos.getGame().getGames().get(2).getGameBudget();
					System.out.println(salida3);
					String salida4 = "" + dataJuegos.getGame().getGames().get(3).getGameBudget();
					System.out.println(salida4);
					String salida5 = "" + dataJuegos.getGame().getGames().get(4).getGameBudget();
					System.out.println(salida5);
					vPre.getpLoteria().setText(salida1);
					vPre.getpBaloto().setText(salida2);
					vPre.getpSuperastro().setText(salida3);
					vPre.getpBetplay().setText(salida4);
					vPre.getpChance().setText(salida5);
					double tmp1 = Double.parseDouble(vPre.getpLoteria().getText());
					double tmp2 = Double.parseDouble(vPre.getpBaloto().getText());
					double tmp3 = Double.parseDouble(vPre.getpSuperastro().getText());
					double tmp4 = Double.parseDouble(vPre.getpBetplay().getText());
					double tmp5 = Double.parseDouble(vPre.getpChance().getText());

					double sumPresupuesto = tmp1 + tmp2 + tmp3 + tmp4 + tmp5;

					if (sumPresupuesto > Double.parseDouble(vr.getPresupuestoTotalField().getText())) {
						aviso.mostrarInfo(
								"Los presupuestos actuales de sus juegos exceden el presupuesto total existente, debe modificarlos a continuación");
						vPre.getpLoteria().setText(null);
						vPre.getpBaloto().setText(null);
						vPre.getpSuperastro().setText(null);
						vPre.getpBetplay().setText(null);
						vPre.getpChance().setText(null);
					} else {
						aviso.mostrarInfo(
								"No hay problema alguno con los presupuestos actuales de sus juegos, puede continuar presionando el boton (Si desea hacer modificaciones, asegurese de que no excedan su presupuesto total)");
						dataJuegos.initializeGames();
						casaApuestas.initializeBettingHouseData();
					}

				} else {

				}

			} else {
				aviso.mostrarInfo("Debe llenar todos los datos para crear la casa de apuestas");
			}
			break;
		}
		case "BotonModificarJuegos": {
			if (!vPre.getpLoteria().getText().equals("") && !vPre.getpBaloto().getText().equals("")
					&& !vPre.getpSuperastro().getText().equals("") && !vPre.getpBetplay().getText().equals("")
					&& !vPre.getpChance().getText().equals("")) {

				boolean temp1 = true;

				try {
					Double.parseDouble(vPre.getpLoteria().getText());

				} catch (NumberFormatException ex) {
					ex.printStackTrace();
					temp1 = false;
					aviso.mostrarInfo("Debe ingresar valores validos.");
				}
				try {
					Double.parseDouble(vPre.getpBaloto().getText());

				} catch (NumberFormatException ex) {
					ex.printStackTrace();
					temp1 = false;
					aviso.mostrarInfo("Debe ingresar valores validos.");
				}
				try {
					Double.parseDouble(vPre.getpSuperastro().getText());

				} catch (NumberFormatException ex) {
					ex.printStackTrace();
					temp1 = false;
					aviso.mostrarInfo("Debe ingresar valores validos.");
				}
				try {
					Double.parseDouble(vPre.getpBetplay().getText());

				} catch (NumberFormatException ex) {
					ex.printStackTrace();
					temp1 = false;
					aviso.mostrarInfo("Debe ingresar valores validos.");
				}
				try {
					Double.parseDouble(vPre.getpChance().getText());

				} catch (NumberFormatException ex) {
					ex.printStackTrace();
					temp1 = false;
					aviso.mostrarInfo("Debe ingresar valores validos.");
				}

				if (temp1 == true) {
					casaApuestas.initializeBettingHouseData();
					double tmp1 = Double.parseDouble(vPre.getpLoteria().getText());
					double tmp2 = Double.parseDouble(vPre.getpBaloto().getText());
					double tmp3 = Double.parseDouble(vPre.getpSuperastro().getText());
					double tmp4 = Double.parseDouble(vPre.getpBetplay().getText());
					double tmp5 = Double.parseDouble(vPre.getpChance().getText());

					double sumPresupuesto = tmp1 + tmp2 + tmp3 + tmp4 + tmp5;

					if (sumPresupuesto <= Double.parseDouble(vr.getPresupuestoTotalField().getText())) {
						dataJuegos.modifyGames("Loteria", "Loteria", vPre.getpLoteria().getText(), 0);
						dataJuegos.modifyGames("Baloto", "Loteria", vPre.getpBaloto().getText(), 1);
						dataJuegos.modifyGames("SuperAstro", "Loteria", vPre.getpSuperastro().getText(), 2);
						dataJuegos.modifyGames("BetPlay", "Deportivo", vPre.getpBetplay().getText(), 3);
						dataJuegos.modifyGames("Chance", "Chance", vPre.getpChance().getText(), 4);

						aviso.mostrarInfo("Información de juegos modificada correctamente");
						vPre.setVisible(false);
						vs.setVisible(true);
						casaApuestas.initializeBettingHouseData();
						if (dataSedes.getSedes().getSedes().size() == casaApuestas.getHouse().getBettingHouse()
								.getNumberOfSites()) {
							aviso.mostrarInfo(
									"No hay problema alguno con la cantidad de sedes creadas, a continuación puede modificar una sede o finalizar la modificación de los datos de la casa de apuestas.");
							vs.getLocalidadTxt().setBounds(40, 225, 400, 25);
							vs.getLocalidadField().setBounds(40, 250, 350, 30);
							vs.getLocalidadAModificarTxt().setVisible(true);
							vs.getLocalidadAModificarField().setVisible(true);
							vs.getBotonModificarSedes().setVisible(true);
							vs.getBotonFinalizar().setVisible(true);
							vs.getBotonSedes().setVisible(false);
							vs.getBotonLlenarSedes().setVisible(true);
						} else if (dataSedes.getSedes().getSedes().size() < casaApuestas.getHouse().getBettingHouse()
								.getNumberOfSites()) {
							aviso.mostrarInfo(
									"Actualmente hay menos sedes creadas que la cantidad ingresada, por favor, cree las sedes que faltan.");
							vs.getLocalidadField().setText(null);
							vs.getEmpleadosField().setText(null);
						} else if (dataSedes.getSedes().getSedes().size() > casaApuestas.getHouse().getBettingHouse()
								.getNumberOfSites()) {
							aviso.mostrarInfo(
									"Actualmente hay más sedes creadas que la cantidad ingresada, por favor, elimine las sedes sobrantes ingresando el nombre de su localidad.");
							vs.getEmpleadosField().setVisible(false);
							vs.getBotonEliminarSede().setVisible(true);
							vs.getBotonSedes().setVisible(false);
							vs.getEmpleadosTxt().setVisible(false);
						}

					} else {
						aviso.mostrarInfo(
								"La suma de los presupuestos excede su presupuesto total, realice de nuevo la distribución del presupuesto");
					}
				}
			} else {
				aviso.mostrarInfo("Debe completar todos los campos.");
			}
			break;

		}
		case "BotonModificarSedes": {
			if (!vs.getLocalidadField().getText().equals("") && !vs.getEmpleadosField().getText().equals("")
					&& !vs.getLocalidadAModificarField().getText().equals("")) {
				boolean tmp = true;
				try {
					Integer.parseInt(vs.getEmpleadosField().getText());
				} catch (NumberFormatException ex) {
					tmp = false;
					aviso.mostrarInfo("Ingrese un número valido");
					ex.printStackTrace();
				}

				if (tmp == true) {
					dataSedes.modificarSede(vs.getLocalidadAModificarField().getText(),
							vs.getLocalidadField().getText(), Integer.parseInt(vs.getEmpleadosField().getText()));

					aviso.mostrarInfo("Sede modificada correctamente.");
				}
			} else {

				aviso.mostrarInfo("Debe llenar todos los campos");

			}
			break;
		}
		case "BotonFinalizar": {
			aviso.mostrarInfo("Modificación completada.");
			vs.setVisible(false);
			ve.setVisible(true);
			ve.getBotonModificar().setVisible(false);
			ve.getBotonReportes().setVisible(false);
			ve.getBotonEliminarApostador().setVisible(false);
			ve.getBotonLeerApostador().setVisible(false);
			ve.getBotonModificarApostador().setVisible(false);
			ve.getBotonApostadores().setBounds(200, 180, 290, 180);
			ve.getBotonApostadores().setVisible(false);
			ve.getBotonApostador().setVisible(true);
			ve.getBotonCasaApuestas().setVisible(true);
			ve.getBotonApuesta().setVisible(false);
			ve.getFlecha().setVisible(true);
			break;
		}
		case "BotonEliminarSede": {
			if (!vs.getLocalidadField().getText().equals("")) {
				aviso.mostrarInfo("Sede eliminada exitosamente");
				aviso.mostrarInfo(dataSedes.eliminarSede(casaApuestas.getHouse().getBettingHouse().getNumberOfSites(),
						vs.getLocalidadField().getText()));
				vs.setVisible(false);
				ve.setVisible(true);
				ve.getBotonModificar().setVisible(false);
				ve.getBotonReportes().setVisible(false);
				ve.getBotonEliminarApostador().setVisible(false);
				ve.getBotonLeerApostador().setVisible(false);
				ve.getBotonModificarApostador().setVisible(false);
				ve.getBotonApostadores().setBounds(200, 180, 290, 180);
				ve.getBotonApostadores().setVisible(false);
				ve.getBotonApostador().setVisible(true);
				ve.getBotonCasaApuestas().setVisible(true);
				ve.getBotonApuesta().setVisible(false);
				ve.getFlecha().setVisible(true);
			} else {
				aviso.mostrarInfo("Debe indicar la sede que desea eliminar.");
			}
			break;
		}
		case "BotonLlenarSedes": {
			if (!vs.getLocalidadField().getText().equals("") && !vs.getEmpleadosField().getText().equals("")) {
				boolean tmp = true;
				try {
					Integer.parseInt(vs.getEmpleadosField().getText());
				} catch (NumberFormatException ex) {
					tmp = false;
					aviso.mostrarInfo("Ingrese un número valido");
					ex.printStackTrace();
				}

				if (tmp == true) {
					casaApuestas.initializeBettingHouseData();
					aviso.mostrarInfo(dataSedes.crearNuevaSede(
							casaApuestas.getHouse().getBettingHouse().getNumberOfSites(),
							vs.getLocalidadField().getText(), Integer.parseInt(vs.getEmpleadosField().getText())));
					if (casaApuestas.getHouse().getBettingHouse().getNumberOfSites() == dataSedes.getSedes().getSedes()
							.size()) {

						aviso.mostrarInfo("Archivo de sedes creado exitosamente");
						ve.setVisible(true);
						vs.setVisible(false);
						ve.getBotonModificar().setVisible(false);
						ve.getBotonReportes().setVisible(false);
						ve.getBotonEliminarApostador().setVisible(false);
						ve.getBotonLeerApostador().setVisible(false);
						ve.getBotonModificarApostador().setVisible(false);
						ve.getBotonApostadores().setBounds(200, 180, 290, 180);
						ve.getBotonApostadores().setVisible(false);
						ve.getBotonApostador().setVisible(true);
						ve.getBotonCasaApuestas().setVisible(true);
						ve.getBotonApuesta().setVisible(false);
						ve.getFlecha().setVisible(true);

					} else {

						vs.getLocalidadField().setText(null);
						vs.getEmpleadosField().setText(null);
					}

				}

			} else {
				aviso.mostrarInfo("Debe llenar todos los campos");
			}
			break;
		}
		case "BotonVentanaApostadores": {
			ve.setVisible(false);
			va.setVisible(true);
			va.getNombreField().setVisible(true);
			va.getNombreTxt().setVisible(true);
			va.getSedeField().setVisible(true);
			va.getSedeTxt().setVisible(true);
			va.getCelularField().setVisible(true);
			va.getDireccionTxt().setVisible(true);
			va.getDireccionField().setVisible(true);
			va.getBotonEliminar().setVisible(false);
			va.getNombreField().setText(null);
			va.getCedulaField().setText(null);
			va.getSedeField().setText(null);
			va.getDireccionField().setText(null);
			va.getCelularField().setText(null);
			va.getNombreTxt().setBounds(40, 110, 400, 25);
			va.getNombreField().setBounds(40, 130, 350, 30);
			va.getCedulaTxt().setBounds(40, 290, 400, 25);
			va.getCedulaField().setBounds(40, 310, 350, 30);
			va.getSedeTxt().setBounds(40, 470, 400, 25);
			va.getSedeField().setBounds(40, 490, 350, 30);
			va.getNombreAModificarField().setVisible(false);
			va.getNombreAModificarTxt().setVisible(false);
			va.getBotonModificar().setVisible(false);
			va.getBotonCrear().setVisible(true);
			aviso.mostrarInfo("Las sedes disponibles son: " + dataSedes.mostrarSedes());
			break;
		}
		case "BotonCrearApostador": {
			if (!va.getNombreField().getText().equalsIgnoreCase("") && !va.getCedulaField().getText().equals("")
					&& !va.getSedeField().getText().equals("") && !va.getDireccionField().getText().equals("")
					&& !va.getCelularField().getText().equals("")) {

				boolean tmp = true;
				try {
					Long.parseLong(va.getCedulaField().getText());
				} catch (NumberFormatException ex) {
					tmp = false;
					aviso.mostrarInfo("Ingrese un número de cédula valido");
					ex.printStackTrace();
				}
				try {
					Long.parseLong(va.getCelularField().getText());
				} catch (NumberFormatException ex) {
					tmp = false;
					aviso.mostrarInfo("Ingrese un número de telefono valido");
					ex.printStackTrace();
				}

				if (tmp == true) {
					dataApostador.crearApostador(va.getNombreField().getText(),
							Long.parseLong(va.getCedulaField().getText()), va.getSedeField().getText(),
							va.getDireccionField().getText(), Long.parseLong(va.getCelularField().getText()));
					aviso.mostrarInfo("Apostador creado exitosamente");
					dataApostador.leerApostadores();
					va.setVisible(false);
					ve.setVisible(true);
					ve.getBotonApostador().setVisible(true);
					ve.getBotonCasaApuestas().setVisible(true);
					ve.getBotonModificar().setVisible(false);
					ve.getBotonApostadores().setVisible(false);
					ve.getBotonEliminarApostador().setVisible(false);
					ve.getBotonLeerApostador().setVisible(false);
					;
					ve.getBotonModificarApostador().setVisible(false);
					ve.getBotonApostadores().setBounds(200, 180, 290, 180);
					ve.getBotonApostadores().setVisible(false);
					ve.getBotonApuesta().setVisible(false);
					ve.getFlecha().setVisible(true);

				}

			} else {
				aviso.mostrarInfo("Debe completar todos los campos.");
			}
			break;
		}
		case "BotonSoyApostador": {
			ve.getBotonEliminarApostador().setVisible(true);
			;
			ve.getBotonLeerApostador().setVisible(true);
			;
			ve.getBotonModificarApostador().setVisible(true);
			ve.getBotonApostadores().setBounds(200, 180, 290, 180);
			ve.getBotonApostadores().setVisible(true);
			ve.getBotonApostador().setVisible(false);
			ve.getBotonCasaApuestas().setVisible(false);
			ve.getBotonApuesta().setVisible(true);
			ve.getFlecha().setVisible(true);
			break;
		}
		case "BotonSoyCasaApuestas": {
			ve.getBotonModificar().setVisible(true);
			ve.getBotonReportes().setVisible(true);
			ve.getFlecha().setVisible(true);
			ve.getBotonApostador().setVisible(false);
			ve.getBotonCasaApuestas().setVisible(false);
			break;
		}
		case "BotonRegresar": {
			ve.getBotonModificar().setVisible(false);
			ve.getBotonReportes().setVisible(false);
			ve.getBotonEliminarApostador().setVisible(false);
			ve.getBotonLeerApostador().setVisible(false);
			ve.getBotonModificarApostador().setVisible(false);
			ve.getBotonApostadores().setBounds(200, 180, 290, 180);
			ve.getBotonApostadores().setVisible(false);
			ve.getBotonApostador().setVisible(true);
			ve.getBotonCasaApuestas().setVisible(true);
			ve.getBotonApuesta().setVisible(false);
			ve.getFlecha().setVisible(true);
			break;
		}

		case "BotonModificarApostador": {
			ve.setVisible(false);
			va.setVisible(true);
			va.getNombreTxt().setBounds(40, 250, 400, 25);
			va.getNombreField().setBounds(40, 270, 350, 30);
			va.getCedulaTxt().setBounds(40, 350, 400, 25);
			va.getCedulaField().setBounds(40, 370, 350, 30);
			va.getSedeTxt().setBounds(40, 450, 400, 25);
			va.getSedeField().setBounds(40, 470, 350, 30);
			va.getNombreAModificarField().setVisible(true);
			va.getNombreAModificarTxt().setVisible(true);
			va.getNombreField().setVisible(true);
			va.getNombreTxt().setVisible(true);
			va.getCelularField().setVisible(true);
			va.getCelularTxt().setVisible(true);
			va.getDireccionField().setVisible(true);
			va.getDireccionTxt().setVisible(true);
			va.getCelularField().setVisible(true);
			va.getCelularTxt().setVisible(true);
			va.getSedeField().setVisible(true);
			va.getSedeTxt().setVisible(true);
			va.getBotonModificar().setVisible(true);
			va.getBotonCrear().setVisible(false);
			va.getBotonEliminar().setVisible(false);
			va.getCedulaField().setText(null);
			aviso.mostrarInfo(
					"A continuación, ingrese el nombre del apostador que desea modificar, y luego, ingrese los nuevos datos del apostador.");
			break;
		}

		case "BtnModificarApostador": {
			if (!va.getNombreAModificarField().getText().equals("")
					&& !va.getNombreField().getText().equalsIgnoreCase("") && !va.getCedulaField().getText().equals("")
					&& !va.getSedeField().getText().equals("") && !va.getDireccionField().getText().equals("")
					&& !va.getCelularField().getText().equals("")) {
				boolean tmp = true;
				try {
					Long.parseLong(va.getCedulaField().getText());
				} catch (NumberFormatException ex) {
					tmp = false;
					aviso.mostrarInfo("Ingrese un número de cédula valido");
					ex.printStackTrace();
				}
				try {
					Long.parseLong(va.getCelularField().getText());
				} catch (NumberFormatException ex) {
					tmp = false;
					aviso.mostrarInfo("Ingrese un número de telefono valido");
					ex.printStackTrace();
				}

				if (tmp == true) {
					dataApostador.modificarApostador(va.getNombreAModificarField().getText(),
							va.getNombreField().getText(), Long.parseLong(va.getCedulaField().getText()),
							va.getSedeField().getText(), va.getDireccionField().getText(),
							Long.parseLong(va.getCelularField().getText()));
					aviso.mostrarInfo("Apostador modificado exitosamente.");
				} else {
					aviso.mostrarInfo("Debe ingresar números validos en los campos de cedula y número");
				}

			} else {
				aviso.mostrarInfo("Debe completar todos los campos");
			}
			break;
		}
		case "BotonEliminarApostador": {
			ve.setVisible(false);
			va.setVisible(true);
			va.getNombreField().setVisible(false);
			va.getNombreTxt().setVisible(false);
			va.getSedeField().setVisible(false);
			va.getSedeTxt().setVisible(false);
			va.getCelularField().setVisible(false);
			va.getCelularTxt().setVisible(false);
			va.getDireccionTxt().setVisible(false);
			va.getDireccionField().setVisible(false);
			va.getBotonEliminar().setVisible(true);
			va.getNombreField().setText(null);
			va.getCedulaField().setText(null);
			va.getSedeField().setText(null);
			va.getDireccionField().setText(null);
			va.getCelularField().setText(null);
			va.getNombreTxt().setBounds(40, 110, 400, 25);
			va.getNombreField().setBounds(40, 130, 350, 30);
			va.getCedulaTxt().setBounds(40, 290, 400, 25);
			va.getCedulaField().setBounds(40, 310, 350, 30);
			va.getSedeTxt().setBounds(40, 470, 400, 25);
			va.getSedeField().setBounds(40, 490, 350, 30);
			va.getNombreAModificarField().setVisible(false);
			va.getNombreAModificarTxt().setVisible(false);
			va.getBotonModificar().setVisible(false);
			va.getBotonCrear().setVisible(false);

			aviso.mostrarInfo("A continuación, ingrese el número de cedula del apostador que desea eliminar.");
			break;
		}
		case "BtnEliminarApostador": {
			if (!va.getCedulaField().getText().equals("")) {
				boolean tmp = true;
				try {
					Long.parseLong(va.getCedulaField().getText());
				} catch (NumberFormatException ex) {
					tmp = false;
					aviso.mostrarInfo("Ingrese un número de cédula valido");
					ex.printStackTrace();
				}
				if (tmp == true) {
					dataApostador.eliminarApostador(Long.parseLong(va.getCedulaField().getText()));
					aviso.mostrarInfo("Apostador eliminado correctamente");
				} else {
					aviso.mostrarInfo("Debe ingresar un número de cedula valido.");
				}
			} else {
				aviso.mostrarInfo("Debe ingresar un número de cedula");
			}
			break;
		}
		case "BotonLeerApostador": {
			dataApostador.inicializarApostadores();
			String apostadores = dataApostador.leerApostadores();
			aviso.mostrarInfo(apostadores);
			break;
		}
		case "BotonRegresarApostadores": {
			va.setVisible(false);
			ve.setVisible(true);
			break;
		}
		case "BotonApuestas": {
			ve.getBotonApostador().setVisible(false);
			ve.getBotonCasaApuestas().setVisible(false);
			ve.getBotonModificar().setVisible(false);
			ve.getBotonApostadores().setVisible(false);
			ve.getBotonEliminarApostador().setVisible(false);
			ve.getBotonLeerApostador().setVisible(false);
			ve.getBotonModificarApostador().setVisible(false);
			ve.getBotonApostadores().setBounds(200, 180, 290, 180);
			ve.getBotonApostadores().setVisible(false);
			ve.getBotonApuesta().setVisible(false);
			ve.getFlecha().setVisible(false);
			ve.getBotonCrearApuesta().setVisible(true);
			ve.getBotonLeerApuestas().setVisible(true);
			ve.getBotonModificarApuesta().setVisible(true);
			ve.getBotonEliminarApuestas().setVisible(true);
			ve.getFlecha2().setVisible(true);
			break;
		}
		case "BotonRealizarApuesta": {
			eleccion = 1;
			ve.getBotonCrearApuesta().setVisible(false);
			ve.getBotonLeerApuestas().setVisible(false);
			ve.getBotonModificarApuesta().setVisible(false);
			ve.getBotonEliminarApuestas().setVisible(false);
			ve.getBotonLoteria().setVisible(true);
			ve.getBotonBaloto().setVisible(true);
			ve.getBotonSuperastro().setVisible(true);
			ve.getBotonBetplay().setVisible(true);
			ve.getBotonChance().setVisible(true);
			ve.getFlecha3().setVisible(true);
			ve.getFlecha2().setVisible(false);
			break;
		}
		case "BotonApostarLoteria": {
			if (eleccion == 1) {
				vl.setVisible(true);
				ve.setVisible(false);
				cedula = aviso.recibirInfo("Por favor, ingrese el número de cedula");
				vl.getBotonApostar().setVisible(true);
				vl.getBotonModificar().setVisible(false);
				vl.getBotonEliminar().setVisible(false);
			} else if (eleccion == 2) {
				vl.setVisible(true);
				ve.setVisible(false);
				cedula = aviso.recibirInfo("Por favor, ingrese el número de cedula");
				numApostado = aviso
						.recibirInfo("Por favor, ingrese el número apostado de la apuesta que desea modificar.");
				vl.getBotonModificar().setVisible(true);
				vl.getBotonApostar().setVisible(false);
				vl.getBotonEliminar().setVisible(false);
			} else if (eleccion == 3) {
				cedula = aviso.recibirInfo("Por favor, ingrese el número de cedula");
				numApostado = aviso
						.recibirInfo("Por favor, ingrese el número apostado de la apuesta que desea eliminar.");
				if (!cedula.equals("") && !numApostado.equals("")) {
					boolean tmp = true;
					try {
						Long.parseLong(cedula);
					} catch (NumberFormatException ex) {
						tmp = false;
					}
					try {
						Integer.parseInt(numApostado);
					} catch (NumberFormatException ex) {
						tmp = false;
					}
					if (tmp == true) {
						al.eliminarApuestaLoteria(Long.parseLong(cedula), Integer.parseInt(numApostado));
						aviso.mostrarInfo("Apuesta eliminada correctamente");
					}
				}
				vl.getBotonModificar().setVisible(false);
				vl.getBotonApostar().setVisible(false);
				vl.getBotonEliminar().setVisible(true);
			} else if (eleccion == 4) {
				al.inicializarApuestasLoteria();
				aviso.mostrarInfo(al.leerApuestaLoteria());
			}
			break;
		}
		case "btnApostarLoteria": {
			if (!vl.getpDiaApuesta().getText().equals("") && !vl.getpNombreLoteria().getText().equals("")
					&& !vl.getpValorApuesta().getText().equals("") && !vl.getpNumeroApostado().getText().equals("")
					&& !vl.getpSerie().getText().equals("") && !cedula.equals("")
					&& vl.getpNumeroApostado().getText().length() == 4) {
				boolean tmp = true;

				String sede = null;
				try {
					Long.parseLong(cedula);
				} catch (NumberFormatException ex) {
					tmp = false;
				}
				try {
					Double.parseDouble(vl.getpValorApuesta().getText());
				} catch (NumberFormatException ex) {
					tmp = false;
				}
				try {
					Integer.parseInt(vl.getpNumeroApostado().getText());
				} catch (NumberFormatException ex) {
					tmp = false;
				}
				try {
					Integer.parseInt(vl.getpSerie().getText());
				} catch (NumberFormatException ex) {
					tmp = false;
				}

				if (tmp == true) {
					for (int i = 0; i < dataApostador.getApostador().getListaApostador().size(); i++) {
						if (Long.parseLong(cedula) == dataApostador.getApostador().getListaApostador().get(i)
								.getCedula()) {
							sede = dataApostador.getApostador().getListaApostador().get(i).getSede();
						}
					}

					al.crearApuestaLoteria(sede, Long.parseLong(cedula), vl.getpDiaApuesta().getText(),
							Double.parseDouble(vl.getpValorApuesta().getText()), vl.getpNombreLoteria().getText(),
							Integer.parseInt(vl.getpNumeroApostado().getText()),
							Integer.parseInt(vl.getpSerie().getText()));

					aviso.mostrarInfo("Recibo: " + "\n" + "Nombre sede: " + sede + "\n" + " Cedula: " + cedula + "\n"
							+ " Dia apuesta: " + vl.getpDiaApuesta().getText() + "\n" + " Valor apuesta: "
							+ vl.getpValorApuesta().getText() + "\n" + " Nombre loteria: "
							+ vl.getpNombreLoteria().getText() + "\n" + " Numero loteria: "
							+ vl.getpNumeroApostado().getText() + "\n" + " Numero serie: " + vl.getpSerie().getText());
				} else {
					aviso.mostrarInfo(
							"Debe ingresar valores validos para cedula, valor de la apuesta, numero apostado y numero de serie");
					cedula = aviso.recibirInfo("Por favor, ingrese el número de cedula");
					vl.getpValorApuesta().setText(null);
					vl.getpNumeroApostado().setText(null);
					vl.getpSerie().setText(null);
				}

			} else {
				aviso.mostrarInfo(
						"Debe ingresar valores en los campos, y asegurarse que el número apostado tenga solo 4 números.");
				cedula = aviso.recibirInfo("Por favor, ingrese el número de cedula");
			}
			break;
		}
		case "btnModificarLoteria": {
			if (!vl.getpDiaApuesta().getText().equals("") && !vl.getpNombreLoteria().getText().equals("")
					&& !vl.getpValorApuesta().getText().equals("") && !vl.getpNumeroApostado().getText().equals("")
					&& !vl.getpSerie().getText().equals("") && !cedula.equals("") && !numApostado.equals("")
					&& vl.getpNumeroApostado().getText().length() == 4) {
				boolean tmp = true;

				String sede = null;
				try {
					Long.parseLong(cedula);
				} catch (NumberFormatException ex) {
					tmp = false;
				}
				try {
					Double.parseDouble(vl.getpValorApuesta().getText());
				} catch (NumberFormatException ex) {
					tmp = false;
				}
				try {
					Integer.parseInt(vl.getpNumeroApostado().getText());
				} catch (NumberFormatException ex) {
					tmp = false;
				}
				try {
					Integer.parseInt(numApostado);
				} catch (NumberFormatException ex) {
					tmp = false;
				}
				try {
					Integer.parseInt(vl.getpSerie().getText());
				} catch (NumberFormatException ex) {
					tmp = false;
				}

				if (tmp == true) {
					for (int i = 0; i < dataApostador.getApostador().getListaApostador().size(); i++) {
						if (Long.parseLong(cedula) == dataApostador.getApostador().getListaApostador().get(i)
								.getCedula()) {
							sede = dataApostador.getApostador().getListaApostador().get(i).getSede();
						}
					}

					al.modificarApuestaLoteria(sede, Long.parseLong(cedula), vl.getpDiaApuesta().getText(),
							Integer.parseInt(numApostado), Double.parseDouble(vl.getpValorApuesta().getText()),
							vl.getpNombreLoteria().getText(), Integer.parseInt(vl.getpNumeroApostado().getText()),
							Integer.parseInt(vl.getpSerie().getText()));
					aviso.mostrarInfo("Apuesta modificada correctamente");
				} else {
					aviso.mostrarInfo(
							"Debe ingresar valores validos para cedula, antiguo numero apostado, valor de la apuesta, numero apostado y numero de serie");
					cedula = aviso.recibirInfo("Por favor, ingrese el número de cedula");
					numApostado = aviso.recibirInfo("Por favor ingrese el numero apostado de la apuesta a modificar");
					vl.getpValorApuesta().setText(null);
					vl.getpNumeroApostado().setText(null);
					vl.getpSerie().setText(null);
				}

			} else {
				aviso.mostrarInfo(
						"Debe ingresar valores en los campos, y asegurarse que el número apostado tenga solo 4 números.");
				cedula = aviso.recibirInfo("Por favor, ingrese el número de cedula");
				numApostado = aviso.recibirInfo("Por favor ingrese el numero apostado de la apuesta a modificar");
			}
			break;
		}
		case "botonFlechaLoteria": {
			vl.setVisible(false);
			vl.getpDiaApuesta().setText(null);
			vl.getpNombreLoteria().setText(null);
			vl.getpNumeroApostado().setText(null);
			vl.getpSerie().setText(null);
			vl.getpValorApuesta().setText(null);
			ve.setVisible(true);
			break;
		}
		case "BotonApostarBaloto": {
			if (eleccion == 1) {
				vb.setVisible(true);

				cedula = aviso.recibirInfo("Por favor, ingrese el número de cedula");
				vb.getBotonApostar().setVisible(true);
				vb.getBotonModificar().setVisible(false);
				vb.getBotonEliminar().setVisible(false);
				vb.getpValorApuesta().setText(null);
				vb.getpNumeroApostado().setText(null);
				vb.getpDiaApuesta().setText(null);

			} else if (eleccion == 2) {
				vb.getpValorApuesta().setText(null);
				vb.getpNumeroApostado().setText(null);
				vb.getpDiaApuesta().setText(null);
				vb.setVisible(true);
				
				cedula = aviso.recibirInfo("Por favor, ingrese el número de cedula");
				numApostado = aviso.recibirInfo(
						"Por favor, ingrese el número apostado de la apuesta que desea modificar (Ingrese los 6 números separados por un espacio cada uno, de la manera 1 2 3 4 5 6");
				vb.getBotonModificar().setVisible(true);
				vb.getBotonApostar().setVisible(false);
				vb.getBotonEliminar().setVisible(false);
			} else if (eleccion == 3) {
				cedula = aviso.recibirInfo("Por favor, ingrese el número de cedula");
				numApostado = aviso.recibirInfo(
						"Por favor, ingrese el número apostado de la apuesta que desea modificar (Ingrese los 6 números separados por un espacio cada uno, de la manera 1 2 3 4 5 6");
				if (!cedula.equals("") && !numApostado.equals("")) {
					boolean tmp = true;
					try {
						Long.parseLong(cedula);
					} catch (NumberFormatException ex) {
						tmp = false;
					}
					try {
						numApostado = numApostado.replaceAll("\\s+", "");
						Integer.parseInt(numApostado);
					} catch (NumberFormatException ex) {
						tmp = false;
					}
					if (tmp == true) {
						ab.eliminarApuestaBaloto(Long.parseLong(cedula), numApostado);
						aviso.mostrarInfo("Apuesta eliminada correctamente");
					}
				}
			} else if (eleccion == 4) {
				aviso.mostrarInfo(ab.leerApuestaBaloto());
			}
			break;
		}
		case "btnApostarBaloto": {
			String sede = "";
			if (!vb.getpDiaApuesta().getText().equals("") && !vb.getpValorApuesta().getText().equals("")
					&& !vb.getpNumeroApostado().getText().equals("") && !cedula.equals("")) {
				boolean tmp = true;

				try {
					Long.parseLong(cedula);
				} catch (NumberFormatException ex) {
					tmp = false;
				}
				try {
					Double.parseDouble(vb.getpValorApuesta().getText());
				} catch (NumberFormatException ex) {
					tmp = false;
				}

				if (tmp == true) {
					for (int i = 0; i < dataApostador.getApostador().getListaApostador().size(); i++) {
						if (Long.parseLong(cedula) == dataApostador.getApostador().getListaApostador().get(i)
								.getCedula()) {
							sede = dataApostador.getApostador().getListaApostador().get(i).getSede();
						}
					}

					aviso.mostrarInfo(ab.crearApuestaBaloto(sede, Long.parseLong(cedula), vb.getpDiaApuesta().getText(),
							Double.parseDouble(vb.getpValorApuesta().getText()), vb.getpNumeroApostado().getText()));

					aviso.mostrarInfo("Recibo: " + "\n" + "Nombre sede: " + sede + "\n" + " Cedula: " + cedula + "\n"
							+ " Dia apuesta: " + vb.getpDiaApuesta().getText() + "\n" + " Valor apuesta: "
							+ vb.getpValorApuesta().getText() + "\n" + " Numero apostado: "
							+ vb.getpNumeroApostado().getText());
				} else {
					aviso.mostrarInfo("Debe ingresar valores numericos validos.");
					cedula = aviso.recibirInfo("Por favor, ingrese el número de cedula");
				}

			} else {
				aviso.mostrarInfo("Debe completar los datos pedidos para realizar la apuesta");
				cedula = aviso.recibirInfo("Por favor, ingrese el número de cedula");
			}

			break;
		}
		case "btnModificarBaloto": {
			if (!vb.getpDiaApuesta().getText().equals("") && !vb.getpValorApuesta().getText().equals("")
					&& !vb.getpNumeroApostado().getText().equals("") && !cedula.equals("") && !numApostado.equals("")) {
				boolean tmp = true;

				String sede = null;
				try {
					Long.parseLong(cedula);
				} catch (NumberFormatException ex) {
					tmp = false;
				}
				try {
					Double.parseDouble(vb.getpValorApuesta().getText());
				} catch (NumberFormatException ex) {
					tmp = false;
				}
				try {
					String temp = vb.getpNumeroApostado().getText();
					temp = temp.replaceAll("\\s+", "");
					Integer.parseInt(temp);
				} catch (NumberFormatException ex) {
					tmp = false;
				}
				try {
					numApostado = numApostado.replaceAll("\\s+", "");
					Integer.parseInt(numApostado);
				} catch (NumberFormatException ex) {
					tmp = false;
				}

				if (tmp == true) {
					for (int i = 0; i < dataApostador.getApostador().getListaApostador().size(); i++) {
						if (Long.parseLong(cedula) == dataApostador.getApostador().getListaApostador().get(i)
								.getCedula()) {
							sede = dataApostador.getApostador().getListaApostador().get(i).getSede();
						}
					}

					aviso.mostrarInfo(ab.modificarApuestaBaloto(sede, Long.parseLong(cedula),
							vb.getpDiaApuesta().getText(), Double.parseDouble(vb.getpValorApuesta().getText()),
							numApostado, vb.getpNumeroApostado().getText()));
					aviso.mostrarInfo("Apuesta modificada correctamente");
				} else {
					aviso.mostrarInfo(
							"Debe ingresar valores validos para cedula, antiguo numero apostado, valor de la apuesta, numero apostado y numero de serie");
					cedula = aviso.recibirInfo("Por favor, ingrese el número de cedula");
					numApostado = aviso.recibirInfo(
							"Por favor, ingrese el número apostado de la apuesta que desea modificar (Ingrese los 6 números separados por un espacio cada uno, de la manera 1 2 3 4 5 6");
					vb.getpValorApuesta().setText(null);
					vb.getpNumeroApostado().setText(null);

				}

			} else {
				aviso.mostrarInfo("Debe ingresar valores validos en los campos");
				cedula = aviso.recibirInfo("Por favor, ingrese el número de cedula");
				numApostado = aviso.recibirInfo(
						"Por favor, ingrese el número apostado de la apuesta que desea modificar (Ingrese los 6 números separados por un espacio cada uno, de la manera 1 2 3 4 5 6");
			}
			break;
		}
		case "botonFlechaBaloto": {
			vb.setVisible(false);
			ve.setVisible(true);
			vb.getpDiaApuesta().setText(null);
			vb.getpNumeroApostado().setText(null);
			vb.getpValorApuesta().setText(null);
			
			break;
		}
		case "BotonApostarSuperastro": {
			if (eleccion == 1) {
				vsa.setVisible(true);

				cedula = aviso.recibirInfo("Por favor, ingrese el número de cedula");
				vsa.getBotonApostar().setVisible(true);
				vsa.getBotonModificar().setVisible(false);
				vsa.getBotonEliminar().setVisible(false);
			} else if (eleccion == 2) {
				vsa.setVisible(true);
			
				cedula = aviso.recibirInfo("Por favor, ingrese el número de cedula");
				numApostado = aviso
						.recibirInfo("Por favor, ingrese el número apostado de la apuesta que desea modificar");
				vsa.getBotonModificar().setVisible(true);
				vsa.getBotonApostar().setVisible(false);
				vsa.getBotonEliminar().setVisible(false);
			} else if (eleccion == 3) {
				cedula = aviso.recibirInfo("Por favor, ingrese el número de cedula");
				numApostado = aviso
						.recibirInfo("Por favor, ingrese el número apostado de la apuesta que desea eliminar");
				if (!cedula.equals("") && !numApostado.equals("")) {
					boolean tmp = true;
					try {
						Long.parseLong(cedula);
					} catch (NumberFormatException ex) {
						tmp = false;
					}
					try {
						Integer.parseInt(numApostado);
					} catch (NumberFormatException ex) {
						tmp = false;
					}
					if (tmp == true) {
						as.eliminarApuestaSuperastro(Long.parseLong(cedula), Integer.parseInt(numApostado));
						aviso.mostrarInfo("Apuesta eliminada correctamente");
					}
				}
				vsa.getBotonModificar().setVisible(false);
				vsa.getBotonApostar().setVisible(false);
				vsa.getBotonEliminar().setVisible(true);
			} else if (eleccion == 4) {
				aviso.mostrarInfo(as.leerApuestaSuperastro());
			}
			break;
		}
		case "btnApostarSuperastro": {
			String sede = "";
			if (!vsa.getpDiaApuesta().getText().equals("") && !vsa.getpValorApuesta().getText().equals("")
					&& !vsa.getpNumeroApostado().getText().equals("") && !cedula.equals("")) {
				boolean tmp = true;

				try {
					Double.parseDouble(vsa.getpValorApuesta().getText());
				} catch (NumberFormatException ex) {
					tmp = false;
				}

				try {
					Long.parseLong(cedula);
				} catch (NumberFormatException ex) {
					tmp = false;
				}
				try {
					Integer.parseInt(vsa.getpNumeroApostado().getText());
				} catch (NumberFormatException ex) {
					tmp = false;
				}

				if (tmp == true) {
					for (int i = 0; i < dataApostador.getApostador().getListaApostador().size(); i++) {
						if (Long.parseLong(cedula) == dataApostador.getApostador().getListaApostador().get(i)
								.getCedula()) {
							sede = dataApostador.getApostador().getListaApostador().get(i).getSede();
						}
					}

					as.crearApuestaSuperastro(sede, Long.parseLong(cedula), vsa.getpDiaApuesta().getText(),
							Double.parseDouble(vsa.getpValorApuesta().getText()),
							vsa.getSignoZodical().getSelectedItem().toString(),
							Integer.parseInt(vsa.getpNumeroApostado().getText()));

					aviso.mostrarInfo("Recibo: " + "\n" + "Nombre sede: " + sede + "\n" + " Cedula: " + cedula + "\n"
							+ " Dia apuesta: " + vsa.getpDiaApuesta().getText() + "\n" + " Valor apuesta: "
							+ vsa.getpValorApuesta().getText() + "\n" + " Signo del zodiado: "
							+ vsa.getSignoZodical().getSelectedItem().toString() + "\n" + " Numero apostado: "
							+ vsa.getpNumeroApostado().getText());
				} else {
					aviso.mostrarInfo("Debe ingresar valores numericos validos.");
					cedula = aviso.recibirInfo("Por favor, ingrese el número de cedula");
				}

			} else {
				aviso.mostrarInfo("Debe completar los datos pedidos para realizar la apuesta");
				cedula = aviso.recibirInfo("Por favor, ingrese el número de cedula");
			}

			break;
		}
		case "btnModificarSuperastro": {
			String sede = "";
			if (!vsa.getpDiaApuesta().getText().equals("") && !vsa.getpValorApuesta().getText().equals("")
					&& !vsa.getpNumeroApostado().getText().equals("") && !cedula.equals("")
					&& !numApostado.equals("")) {
				boolean tmp = true;

				try {
					Double.parseDouble(vsa.getpValorApuesta().getText());
				} catch (NumberFormatException ex) {
					tmp = false;
				}

				try {
					Long.parseLong(cedula);
				} catch (NumberFormatException ex) {
					tmp = false;
				}
				try {
					Integer.parseInt(vsa.getpNumeroApostado().getText());
				} catch (NumberFormatException ex) {
					tmp = false;
				}

				if (tmp == true) {
					for (int i = 0; i < dataApostador.getApostador().getListaApostador().size(); i++) {
						if (Long.parseLong(cedula) == dataApostador.getApostador().getListaApostador().get(i)
								.getCedula()) {
							sede = dataApostador.getApostador().getListaApostador().get(i).getSede();
						}
					}

					as.modificarApuestaSuperastro(sede, Long.parseLong(cedula), vsa.getpDiaApuesta().getText(),
							Integer.parseInt(numApostado), Double.parseDouble(vsa.getpValorApuesta().getText()),
							vsa.getSignoZodical().getSelectedItem().toString(),
							Integer.parseInt(vsa.getpNumeroApostado().getText()));

					aviso.mostrarInfo("Recibo: " + "\n" + "Nombre sede: " + sede + "\n" + " Cedula: " + cedula + "\n"
							+ " Dia apuesta: " + vsa.getpDiaApuesta().getText() + "\n" + " Valor apuesta: "
							+ vsa.getpValorApuesta().getText() + "\n" + " Signo del zodiado: "
							+ vsa.getSignoZodical().getSelectedItem().toString() + "\n" + " Numero apostado: "
							+ vsa.getpNumeroApostado().getText());
				} else {
					aviso.mostrarInfo("Debe ingresar valores numericos validos.");
					cedula = aviso.recibirInfo("Por favor, ingrese el número de cedula");
				}

			} else {
				aviso.mostrarInfo("Debe completar los datos pedidos para realizar la apuesta");
				cedula = aviso.recibirInfo("Por favor, ingrese el número de cedula");
			}

			break;
		}
		case "botonFlechaSuperastro": {
			vsa.setVisible(false);
			ve.setVisible(true);
			vsa.getpDiaApuesta().setText(null);
			vsa.getpNumeroApostado().setText(null);
			vsa.getpValorApuesta().setText(null);
			
			break;
		}
		case "BotonApostarBetplay": {
			if (eleccion == 1) {
				vbp.setVisible(true);
				vbp.getpDiaApuesta().setText(null);
				vbp.getpValorApuesta().setText(null);
				cedula = aviso.recibirInfo("Por favor, ingrese el número de cedula");
				vbp.getBotonApostar().setVisible(true);
				vbp.getBotonModificar().setVisible(false);
				vbp.getBotonEliminar().setVisible(false);
			} else if (eleccion == 2) {
				vbp.getpDiaApuesta().setText(null);
				vbp.getpValorApuesta().setText(null);
				vbp.setVisible(true);
				
				cedula = aviso.recibirInfo("Por favor, ingrese el número de cedula");
				numApostado = aviso
						.recibirInfo("Por favor ingrese el día de la semana en el que hizo la apuesta a modificar");
				vbp.getBotonModificar().setVisible(true);
				vbp.getBotonApostar().setVisible(false);
				vbp.getBotonEliminar().setVisible(false);
			} else if (eleccion == 3) {
				boolean verificacion = true;
				cedula = aviso.recibirInfo("Por favor, ingrese el número de cedula");
				numApostado = aviso
						.recibirInfo("Por favor ingrese el día de la semana en el que hizo la apuesta a eliminar");
				try {
					Long.parseLong(cedula);
				} catch (NumberFormatException ex) {
					verificacion = false;
				}
				if (verificacion == true) {
					abp.eliminarApuestaBetplay(Long.parseLong(cedula), numApostado);
				}
				vbp.getBotonModificar().setVisible(false);
				vbp.getBotonApostar().setVisible(false);
				vbp.getBotonEliminar().setVisible(true);
			} else if (eleccion == 4) {
				aviso.mostrarInfo(abp.leerApuestaBetplay());
			}
			break;
		}
		case "btnApostarBetplay": {
			if (!cedula.equals("") && !vbp.getpDiaApuesta().getText().equals("")
					&& !vbp.getpValorApuesta().getText().equals("")) {
				boolean tmp = true;
				String sede = null;
				try {
					Double.parseDouble(vbp.getpValorApuesta().getText());
				} catch (NumberFormatException ex) {
					tmp = false;
				}

				try {
					Long.parseLong(cedula);
				} catch (NumberFormatException ex) {
					tmp = false;
				}

				if (tmp == true) {
					for (int i = 0; i < dataApostador.getApostador().getListaApostador().size(); i++) {
						if (Long.parseLong(cedula) == dataApostador.getApostador().getListaApostador().get(i)
								.getCedula()) {
							sede = dataApostador.getApostador().getListaApostador().get(i).getSede();
						}
					}

					aviso.mostrarInfo(abp.crearApuestaBetplay(sede, Long.parseLong(cedula),
							vbp.getpDiaApuesta().getText(), Double.parseDouble(vbp.getpValorApuesta().getText()),
							vbp.getSantafeMillonarios().getSelectedItem().toString(),
							vbp.getNacionalMedellin().getSelectedItem().toString(),
							vbp.getAmericaCali().getSelectedItem().toString(),
							vbp.getJuniorUnion().getSelectedItem().toString(),
							vbp.getCucutaBucaramanga().getSelectedItem().toString(),
							vbp.getPereiraOnce().getSelectedItem().toString(),
							vbp.getAguilasEnvigado().getSelectedItem().toString(),
							vbp.getPatriotasChico().getSelectedItem().toString(),
							vbp.getTolimaHuila().getSelectedItem().toString(),
							vbp.getBarcelonaMadrid().getSelectedItem().toString(),
							vbp.getArsenalChelsea().getSelectedItem().toString(),
							vbp.getUnitedCity().getSelectedItem().toString(),
							vbp.getLiverpoolEverton().getSelectedItem().toString(),
							vbp.getBayernBorussia().getSelectedItem().toString()));

					aviso.mostrarInfo("Apuesta realizada correctamente");

					aviso.mostrarInfo("Recibo: " + "\n" + "Nombre sede: " + sede + "\n" + " Cedula: " + cedula + "\n"
							+ " Dia apuesta: " + vbp.getpDiaApuesta().getText() + "\n" + " Valor apuesta: "
							+ vbp.getpValorApuesta().getText() + "\n" + " Partido 1: "
							+ vbp.getSantafeMillonarios().getSelectedItem().toString() + "\n" + " Partido 2: "
							+ vbp.getNacionalMedellin().getSelectedItem().toString() + "\n" + " Partido 3: "
							+ vbp.getAmericaCali().getSelectedItem().toString() + "\n" + " Partido 4: "
							+ vbp.getJuniorUnion().getSelectedItem().toString() + "\n" + " Partido 5: "
							+ vbp.getCucutaBucaramanga().getSelectedItem().toString() + "\n" + " Partido 6: "
							+ vbp.getPereiraOnce().getSelectedItem().toString() + "\n" + " Partido 7: "
							+ vbp.getAguilasEnvigado().getSelectedItem().toString() + "\n" + " Partido 8: "
							+ vbp.getPatriotasChico().getSelectedItem().toString() + "\n" + " Partido 9: "
							+ vbp.getTolimaHuila().getSelectedItem().toString() + "\n" + " Partido 10: "
							+ vbp.getBarcelonaMadrid().getSelectedItem().toString() + "\n" + " Partido 11: "
							+ vbp.getArsenalChelsea().getSelectedItem().toString() + "\n" + " Partido 12: "
							+ vbp.getUnitedCity().getSelectedItem().toString() + "\n" + " Partido 13: "
							+ vbp.getLiverpoolEverton().getSelectedItem().toString() + "\n" + " Partido 14: "
							+ vbp.getBayernBorussia().getSelectedItem().toString());

				} else {
					aviso.mostrarInfo("Debe ingresar valores numericos validos.");
					cedula = aviso.recibirInfo("Por favor, ingrese el número de cedula");
				}

			} else {
				aviso.mostrarInfo("Debe llenar todos los datos.");
				cedula = aviso.recibirInfo("Por favor, ingrese el número de cedula");
			}
			break;
		}
		case "btnModificarBetplay": {
			if (!cedula.equals("") && !vbp.getpDiaApuesta().getText().equals("")
					&& !vbp.getpValorApuesta().getText().equals("") && !numApostado.equals("")) {
				boolean tmp = true;
				String sede = null;
				try {
					Double.parseDouble(vbp.getpValorApuesta().getText());
				} catch (NumberFormatException ex) {
					tmp = false;
				}

				try {
					Long.parseLong(cedula);
				} catch (NumberFormatException ex) {
					tmp = false;
				}

				if (tmp == true) {
					for (int i = 0; i < dataApostador.getApostador().getListaApostador().size(); i++) {
						if (Long.parseLong(cedula) == dataApostador.getApostador().getListaApostador().get(i)
								.getCedula()) {
							sede = dataApostador.getApostador().getListaApostador().get(i).getSede();
						}
					}

					aviso.mostrarInfo(abp.modificarApuestaBetplay(sede, Long.parseLong(cedula), numApostado,
							vbp.getpDiaApuesta().getText(), Double.parseDouble(vbp.getpValorApuesta().getText()),
							vbp.getSantafeMillonarios().getSelectedItem().toString(),
							vbp.getNacionalMedellin().getSelectedItem().toString(),
							vbp.getAmericaCali().getSelectedItem().toString(),
							vbp.getJuniorUnion().getSelectedItem().toString(),
							vbp.getCucutaBucaramanga().getSelectedItem().toString(),
							vbp.getPereiraOnce().getSelectedItem().toString(),
							vbp.getAguilasEnvigado().getSelectedItem().toString(),
							vbp.getPatriotasChico().getSelectedItem().toString(),
							vbp.getTolimaHuila().getSelectedItem().toString(),
							vbp.getBarcelonaMadrid().getSelectedItem().toString(),
							vbp.getArsenalChelsea().getSelectedItem().toString(),
							vbp.getUnitedCity().getSelectedItem().toString(),
							vbp.getLiverpoolEverton().getSelectedItem().toString(),
							vbp.getBayernBorussia().getSelectedItem().toString()));

					aviso.mostrarInfo("Apuesta modificada correctamente");

					aviso.mostrarInfo("Recibo: " + "\n" + "Nombre sede: " + sede + "\n" + " Cedula: " + cedula + "\n"
							+ " Dia apuesta: " + vbp.getpDiaApuesta().getText() + "\n" + " Valor apuesta: "
							+ vbp.getpValorApuesta().getText() + "\n" + " Partido 1: "
							+ vbp.getSantafeMillonarios().getSelectedItem().toString() + "\n" + " Partido 2: "
							+ vbp.getNacionalMedellin().getSelectedItem().toString() + "\n" + " Partido 3: "
							+ vbp.getAmericaCali().getSelectedItem().toString() + "\n" + " Partido 4: "
							+ vbp.getJuniorUnion().getSelectedItem().toString() + "\n" + " Partido 5: "
							+ vbp.getCucutaBucaramanga().getSelectedItem().toString() + "\n" + " Partido 6: "
							+ vbp.getPereiraOnce().getSelectedItem().toString() + "\n" + " Partido 7: "
							+ vbp.getAguilasEnvigado().getSelectedItem().toString() + "\n" + " Partido 8: "
							+ vbp.getPatriotasChico().getSelectedItem().toString() + "\n" + " Partido 9: "
							+ vbp.getTolimaHuila().getSelectedItem().toString() + "\n" + " Partido 10: "
							+ vbp.getBarcelonaMadrid().getSelectedItem().toString() + "\n" + " Partido 11: "
							+ vbp.getArsenalChelsea().getSelectedItem().toString() + "\n" + " Partido 12: "
							+ vbp.getUnitedCity().getSelectedItem().toString() + "\n" + " Partido 13: "
							+ vbp.getLiverpoolEverton().getSelectedItem().toString() + "\n" + " Partido 14: "
							+ vbp.getBayernBorussia().getSelectedItem().toString());

				} else {
					aviso.mostrarInfo("Debe ingresar valores numericos validos.");
					cedula = aviso.recibirInfo("Por favor, ingrese el número de cedula");
				}

			} else {
				aviso.mostrarInfo("Debe llenar todos los datos.");
				cedula = aviso.recibirInfo("Por favor, ingrese el número de cedula");
			}
			break;
		}
		case "botonFlechaBetplay": {
			vbp.setVisible(false);
			ve.setVisible(true);
			vbp.getpDiaApuesta().setText(null);
			vbp.getpValorApuesta().setText(null);
			break;
		}
		case "BotonApostarChance": {
			if (eleccion == 1) {
				vc.setVisible(true);

				cedula = aviso.recibirInfo("Por favor, ingrese el número de cedula");
				vc.getBotonApostar().setVisible(true);
				vc.getBotonModificar().setVisible(false);
				vc.getBotonEliminar().setVisible(false);
			} else if (eleccion == 2) {
				vc.setVisible(true);
				ve.setVisible(false);
				cedula = aviso.recibirInfo("Por favor, ingrese el número de cedula");
				numApostado = aviso.recibirInfo("Por favor, ingrese el número apostado anteriormente");
				vc.getBotonModificar().setVisible(true);
				vc.getBotonApostar().setVisible(false);
				vc.getBotonEliminar().setVisible(false);
			} else if (eleccion == 3) {
				cedula = aviso.recibirInfo("Por favor, ingrese el número de cedula");
				numApostado = aviso.recibirInfo("Por favor, ingrese el número apostado anteriormente");
				if (!cedula.equals("") && !numApostado.equals("")) {
					boolean tmp = true;
					try {
						Long.parseLong(cedula);
					} catch (NumberFormatException ex) {
						tmp = false;
					}
					try {
						Integer.parseInt(numApostado);
					} catch (NumberFormatException ex) {
						tmp = false;
					}
					if (tmp == true) {
						ac.eliminarApuestaChance(Long.parseLong(cedula), Integer.parseInt(numApostado));
						aviso.mostrarInfo("Apuesta eliminada correctamente");
					}
				}
				vc.getBotonModificar().setVisible(false);
				vc.getBotonApostar().setVisible(false);
				vc.getBotonEliminar().setVisible(true);
			} else if (eleccion == 4) {
				aviso.mostrarInfo(ac.leerApuestaChance());
			}
			break;
		}
		case "btnApostarChance": {
			String sede = "";
			if (!vc.getpDiaApuesta().getText().equals("") && !vc.getpValorApuesta().getText().equals("")
					&& !vc.getpNumeroApostado().getText().equals("") && !vc.getpNombreLoteria().getText().equals("")
					&& !cedula.equals("")) {
				boolean tmp = true;

				try {
					Double.parseDouble(vc.getpValorApuesta().getText());
				} catch (NumberFormatException ex) {
					tmp = false;
				}

				try {
					Long.parseLong(cedula);
				} catch (NumberFormatException ex) {
					tmp = false;
				}
				try {
					Integer.parseInt(vc.getpNumeroApostado().getText());
				} catch (NumberFormatException ex) {
					tmp = false;
				}

				if (tmp == true) {
					for (int i = 0; i < dataApostador.getApostador().getListaApostador().size(); i++) {
						if (Long.parseLong(cedula) == dataApostador.getApostador().getListaApostador().get(i)
								.getCedula()) {
							sede = dataApostador.getApostador().getListaApostador().get(i).getSede();
						}
					}

					ac.crearApuestaChance(sede, Long.parseLong(cedula), vc.getpDiaApuesta().getText(),
							Double.parseDouble(vc.getpValorApuesta().getText()), vc.getpNombreLoteria().getText(),
							Integer.parseInt(vc.getpNumeroApostado().getText()));

					aviso.mostrarInfo("Recibo: " + "\n" + "Nombre sede: " + sede + "\n" + " Cedula: " + cedula + "\n"
							+ " Dia apuesta: " + vc.getpDiaApuesta().getText() + "\n" + " Valor apuesta: "
							+ vc.getpValorApuesta().getText() + "\n" + " Signo del zodiado: "
							+ vc.getpNombreLoteria().getText() + "\n" + " Numero apostado: "
							+ vc.getpNumeroApostado().getText());
				} else {
					aviso.mostrarInfo("Debe ingresar valores numericos validos.");
					cedula = aviso.recibirInfo("Por favor, ingrese el número de cedula");
				}

			} else {
				aviso.mostrarInfo("Debe completar los datos pedidos para realizar la apuesta");
				cedula = aviso.recibirInfo("Por favor, ingrese el número de cedula");
			}

			break;
		}
		case "btnModificarChance": {
			String sede = "";
			if (!vc.getpDiaApuesta().getText().equals("") && !vc.getpValorApuesta().getText().equals("")
					&& !vc.getpNumeroApostado().getText().equals("") && !vc.getpNombreLoteria().getText().equals("")
					&& !cedula.equals("") && !numApostado.equals("")) {
				boolean tmp = true;

				try {
					Double.parseDouble(vc.getpValorApuesta().getText());
				} catch (NumberFormatException ex) {
					tmp = false;
				}

				try {
					Long.parseLong(cedula);
				} catch (NumberFormatException ex) {
					tmp = false;
				}
				try {
					Integer.parseInt(vc.getpNumeroApostado().getText());
				} catch (NumberFormatException ex) {
					tmp = false;
				}

				try {
					Integer.parseInt(numApostado);
				} catch (NumberFormatException ex) {
					tmp = false;
				}

				if (tmp == true) {
					for (int i = 0; i < dataApostador.getApostador().getListaApostador().size(); i++) {
						if (Long.parseLong(cedula) == dataApostador.getApostador().getListaApostador().get(i)
								.getCedula()) {
							sede = dataApostador.getApostador().getListaApostador().get(i).getSede();
						}
					}

					ac.modificarApuestaChance(sede, Long.parseLong(cedula), vc.getpDiaApuesta().getText(),
							Integer.parseInt(numApostado), Double.parseDouble(vc.getpValorApuesta().getText()),
							vc.getpNombreLoteria().getText(), Integer.parseInt(vc.getpNumeroApostado().getText()));

					aviso.mostrarInfo("Recibo: " + "\n" + "Nombre sede: " + sede + "\n" + " Cedula: " + cedula + "\n"
							+ " Dia apuesta: " + vc.getpDiaApuesta().getText() + "\n" + " Valor apuesta: "
							+ vc.getpValorApuesta().getText() + "\n" + " Signo del zodiado: "
							+ vc.getpNombreLoteria().getText() + "\n" + " Numero apostado: "
							+ vc.getpNumeroApostado().getText());
				} else {
					aviso.mostrarInfo("Debe ingresar valores numericos validos.");
					cedula = aviso.recibirInfo("Por favor, ingrese el número de cedula");
				}

			} else {
				aviso.mostrarInfo("Debe completar los datos pedidos para realizar la apuesta");
				cedula = aviso.recibirInfo("Por favor, ingrese el número de cedula");
			}

			break;
		}
		case "botonFlechaChance": {
			vc.setVisible(false);
			ve.setVisible(true);
			vc.getpDiaApuesta().setText(null);
			vc.getpNombreLoteria().setText(null);
			vc.getpNumeroApostado().setText(null);
			vc.getpValorApuesta().setText(null);
			
			break;
		}
		case "BotonModificarApuesta": {
			eleccion = 2;
			ve.getBotonCrearApuesta().setVisible(false);
			ve.getBotonLeerApuestas().setVisible(false);
			ve.getBotonModificarApuesta().setVisible(false);
			ve.getBotonEliminarApuestas().setVisible(false);
			ve.getBotonLoteria().setVisible(true);
			ve.getBotonBaloto().setVisible(true);
			ve.getBotonSuperastro().setVisible(true);
			ve.getBotonBetplay().setVisible(true);
			ve.getBotonChance().setVisible(true);
			ve.getFlecha3().setVisible(true);
			ve.getFlecha2().setVisible(false);
			break;
		}
		case "BotonEliminarApuesta": {
			eleccion = 3;
			ve.getBotonCrearApuesta().setVisible(false);
			ve.getBotonLeerApuestas().setVisible(false);
			ve.getBotonModificarApuesta().setVisible(false);
			ve.getBotonEliminarApuestas().setVisible(false);
			ve.getBotonLoteria().setVisible(true);
			ve.getBotonBaloto().setVisible(true);
			ve.getBotonSuperastro().setVisible(true);
			ve.getBotonBetplay().setVisible(true);
			ve.getBotonChance().setVisible(true);
			ve.getFlecha3().setVisible(true);
			ve.getFlecha2().setVisible(false);
			break;
		}
		case "BotonLeerApuesta": {
			eleccion = 4;
			ve.getBotonCrearApuesta().setVisible(false);
			ve.getBotonLeerApuestas().setVisible(false);
			ve.getBotonModificarApuesta().setVisible(false);
			ve.getBotonEliminarApuestas().setVisible(false);
			ve.getBotonLoteria().setVisible(true);
			ve.getBotonBaloto().setVisible(true);
			ve.getBotonSuperastro().setVisible(true);
			ve.getBotonBetplay().setVisible(true);
			ve.getBotonChance().setVisible(true);
			ve.getFlecha3().setVisible(true);
			ve.getFlecha2().setVisible(false);
			break;
		}
		case "BotonRegresarApuestas": {
			ve.getBotonEliminarApostador().setVisible(true);
			;
			ve.getBotonLeerApostador().setVisible(true);
			;
			ve.getBotonModificarApostador().setVisible(true);
			ve.getBotonApostadores().setBounds(200, 180, 290, 180);
			ve.getBotonApostadores().setVisible(true);
			ve.getBotonApostador().setVisible(false);
			ve.getBotonCasaApuestas().setVisible(false);
			ve.getBotonApuesta().setVisible(true);
			ve.getFlecha().setVisible(true);
			ve.getBotonCrearApuesta().setVisible(false);
			ve.getBotonLeerApuestas().setVisible(false);
			ve.getBotonModificarApuesta().setVisible(false);
			ve.getBotonEliminarApuestas().setVisible(false);
			ve.getFlecha2().setVisible(false);
			break;
		}
		case "BotonRegresarJuegos": {
			ve.getBotonCrearApuesta().setVisible(true);
			ve.getBotonLeerApuestas().setVisible(true);
			ve.getBotonModificarApuesta().setVisible(true);
			ve.getBotonEliminarApuestas().setVisible(true);
			ve.getBotonLoteria().setVisible(false);
			ve.getBotonBaloto().setVisible(false);
			ve.getBotonSuperastro().setVisible(false);
			ve.getBotonBetplay().setVisible(false);
			ve.getBotonChance().setVisible(false);
			ve.getFlecha2().setVisible(true);
			ve.getFlecha3().setVisible(false);
			break;
		}

		}
	}
}
