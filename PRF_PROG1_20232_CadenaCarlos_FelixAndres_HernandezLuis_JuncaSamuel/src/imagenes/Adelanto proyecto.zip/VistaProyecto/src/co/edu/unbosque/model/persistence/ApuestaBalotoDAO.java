package co.edu.unbosque.model.persistence;

import java.io.File;
import java.util.ArrayList;

public class ApuestaBalotoDAO {
	private ArrayList<ApuestaBalotoDTO> apuestasBaloto;
	private ArchivoBaloto archivoBaloto;

	public ApuestaBalotoDAO() {
		apuestasBaloto = new ArrayList<ApuestaBalotoDTO>();
		archivoBaloto = new ArchivoBaloto();
	}

	public String crearApuestaBaloto(String nombreSede, long cedula, String diaApuesta, double valorApuesta,
			String numApostado) {
		String salida = null;
		boolean verificacion = false;
		String[] numerosString = numApostado.split(" ");
		int[] numeros = new int[numerosString.length];
		for (int i = 0; i < numerosString.length; i++) {
			numeros[i] = Integer.parseInt(numerosString[i]);
			if (numeros[i] > 1 && numeros[i] < 45) {
				verificacion = true;
			} else {
				verificacion = false;
			}
		}

		for (int i = 0; i < numeros.length; i++) {
			int tmp = numeros[i];
			for (int j = 1; i < numeros.length; i++) {
				if (tmp != numeros[j]) {
					verificacion = true;
				} else {
					verificacion = false;
				}
			}
		}
		if (numerosString.length != 6) {
			salida = "Deben haber 6 números.";
			verificacion = false;
		}

		if (verificacion == true) {
			archivoBaloto.crearArchivo();
			numApostado = numApostado.replaceAll("\\s+", "");
			apuestasBaloto.add(
					new ApuestaBalotoDTO(nombreSede, cedula, diaApuesta, valorApuesta, Integer.parseInt(numApostado)));
			archivoBaloto.escribirArchivo(apuestasBaloto);
			salida = "Apuesta realizada exitosamente";
		} else {
			salida = "Error, debe ingresar 6 numeros que no se repitan y que estén entre 1 y 45";
		}

		return salida;
	}

	public String modificarApuestaBaloto(String nombreSede, long cedula, String diaApuesta, double valorApuesta,
			String numApostado, String nuevoNumApostado) {
		
		String salida = null;
		
		for (int i = 0; i < apuestasBaloto.size(); i++) {
			
			if (nombreSede.equalsIgnoreCase(apuestasBaloto.get(i).getNombreSede())
					&& cedula == apuestasBaloto.get(i).getNumCedula()
					&& Integer.parseInt(numApostado) == apuestasBaloto.get(i).getNumeroApostado()) {
				
				numApostado = numApostado.replaceAll("\\s+", "");
				boolean verificacion = false;
				String[] numerosString = nuevoNumApostado.split(" ");
				int[] numeros = new int[numerosString.length];
				
				for (int j = 0; j < numerosString.length; j++) {
					numeros[j] = Integer.parseInt(numerosString[j]);
					if (numeros[j] >= 1 && numeros[j] <= 45) {
						verificacion = true;
					} else {
						verificacion = false;
						salida = "los numeros no estan entre 1 y 45";
					}
				}

				for (int j = 0; j < numeros.length; j++) {
					int tmp = numeros[j];
					for (int k = j++; k < numeros.length; k++) {
						if (tmp != numeros[k]) {
							verificacion = true;
						} else {
							verificacion = false;
							salida = "Los números "+numeros[j]+" y "+numeros[k]+" se repiten";
						}
					}
				}
				if (numerosString.length != 6) {
					salida = "Deben haber 6 números.";
					verificacion = false;
				}

				if (verificacion == true) {
					File f = new File("data/apuestas-baloto.dat");
					f.delete();
					archivoBaloto.crearArchivo();
					nuevoNumApostado = nuevoNumApostado.replaceAll("\\s+", "");
					apuestasBaloto.set(i, new ApuestaBalotoDTO(nombreSede, cedula, diaApuesta, valorApuesta,
							Integer.parseInt(nuevoNumApostado)));
					archivoBaloto.escribirArchivo(apuestasBaloto);
					salida = "Apuesta realizada exitosamente";
				}
			}
		}
		return salida;
	}

	public String leerApuestas() {
		String printable = "";
		for (ApuestaBalotoDTO apuestaBalotoDTO : apuestasBaloto) {
			printable += apuestaBalotoDTO.toString();
		}
		return printable;
	}

	public void eliminarApuestaBaloto(long cedula, String numeroApostado) {
		numeroApostado = numeroApostado.replaceAll("\\s+", "");
		for (int i = 0; i < apuestasBaloto.size(); i++) {
			if (cedula == apuestasBaloto.get(i).getNumCedula()
					&& Integer.parseInt(numeroApostado) == apuestasBaloto.get(i).getNumeroApostado()) {
				apuestasBaloto.remove(i);
			}
		}
		File tmp = new File("data/apuestas-baloto.dat");
		tmp.delete();
		archivoBaloto.crearArchivo();
		archivoBaloto.escribirArchivo(apuestasBaloto);
	}

	public void inicializarArchivo() {
		apuestasBaloto = archivoBaloto.inicializarArchivo();
	}

	public ArrayList<ApuestaBalotoDTO> getApuestasBaloto() {
		return apuestasBaloto;
	}

	public void setApuestasBaloto(ArrayList<ApuestaBalotoDTO> apuestasBaloto) {
		this.apuestasBaloto = apuestasBaloto;
	}

}
