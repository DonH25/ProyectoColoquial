package co.edu.unbosque.model;

import co.edu.unbosque.model.persistence.GamesDAO;

public class GamesData {
	
	private GamesDAO game;
	
	
	public GamesData() {
		game = new GamesDAO();
	}
	
	public void createGames(String name, String typeGame, String gameBudget) {
		if (!name.isEmpty()||!typeGame.isBlank()||!gameBudget.isBlank()) {
		game.createGames(name, typeGame, gameBudget);
		}
		else {
			System.out.println("Los datos se encuentran vacios, debe completar los datos correctamente.");
		}
	}
	
	public void modifyGames (String name, String typeGame, String newGameBudget, int pos) {
		game.modifyGames(name, name, newGameBudget, pos);
	}
	
	public void initializeGames () {
		game.initializeGames();
	}

	public GamesDAO getGame() {
		return game;
	}

	public void setGame(GamesDAO game) {
		this.game = game;
	}
	
	

}
