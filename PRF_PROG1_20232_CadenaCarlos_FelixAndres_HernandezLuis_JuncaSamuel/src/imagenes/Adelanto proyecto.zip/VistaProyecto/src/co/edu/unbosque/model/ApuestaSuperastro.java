package co.edu.unbosque.model;

import co.edu.unbosque.model.persistence.ApuestaSuperastroDAO;

public class ApuestaSuperastro {
	
	private ApuestaSuperastroDAO apuestaSuperastro;
	
	public ApuestaSuperastro() {
		apuestaSuperastro = new ApuestaSuperastroDAO();
	}
	
	public void crearApuestaSuperastro (String nombreSede, long cedula, String diaApuesta, double valorApuesta,
			String signoZodiaco, int numeroApostado) {
		apuestaSuperastro.crearApuestaSuperastro(nombreSede, cedula, diaApuesta, valorApuesta, signoZodiaco, numeroApostado);
	}
	
	public void modificarApuestaSuperastro(String nombreSede, long cedula, String diaApuesta, int anteriorNumeroApostado,
			double nuevoValorApuesta, String nuevoSignoZodiaco, int nuevoNumeroApostado) {
		apuestaSuperastro.modificarApuestaSuperastro(nombreSede, cedula, diaApuesta, anteriorNumeroApostado, nuevoValorApuesta, nuevoSignoZodiaco, nuevoNumeroApostado);
	}
	
	public String leerApuestaSuperastro () {
		return apuestaSuperastro.leerApuestas();
	}
	
	public void eliminarApuestaSuperastro (long cedula, int numeroApostado) {
		apuestaSuperastro.eliminarApuestaSuperastro(cedula, numeroApostado);
	}
	
	public void inicializarApuestasSuperastro () {
		apuestaSuperastro.inicializarApuestasSuperastro();
	}

	public ApuestaSuperastroDAO getApuestaSuperastro() {
		return apuestaSuperastro;
	}

	public void setApuestaSuperastro(ApuestaSuperastroDAO apuestaSuperastro) {
		this.apuestaSuperastro = apuestaSuperastro;
	}
	
	
}
