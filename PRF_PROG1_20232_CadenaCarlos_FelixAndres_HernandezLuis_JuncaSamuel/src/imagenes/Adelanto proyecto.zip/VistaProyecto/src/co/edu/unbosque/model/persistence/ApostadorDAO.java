package co.edu.unbosque.model.persistence;

import java.io.File;
import java.util.ArrayList;
import co.edu.unbosque.model.persistence.ApostadorDTO;

public class ApostadorDAO implements CRUDOperation {
	private ArrayList<ApostadorDTO> listaApostador;
	private ArchivoApostadores f;
	private File archivoApostador;

	public ApostadorDAO() {
		listaApostador = new ArrayList<>();
		f = new ArchivoApostadores();
		archivoApostador = new File("data/apostadores.dat");
	}

	@Override
	public void create(String... strs) {
		ApostadorDTO apostadorTemp = new ApostadorDTO();
		apostadorTemp.setNombre(strs[0]);
		apostadorTemp.setCedula(Long.parseLong(strs[1]));
		apostadorTemp.setSede(strs[2]);
		apostadorTemp.setDireccion(strs[3]);
		apostadorTemp.setNumCelular(Long.parseLong(strs[4]));
		listaApostador.add(apostadorTemp);
	}

	@Override
	public void create(Object obj) {
		listaApostador.add((ApostadorDTO) obj);
		f.crearArchivo();
		f.escribirArchivoApostador(listaApostador);

	}

	@Override
	public String readAll() {
		String printable = "";
		for (ApostadorDTO apostadorDTO : listaApostador) {
			printable += apostadorDTO.toString();
		}
		return printable;
	}

	@Override
	public boolean updateByIndex(int index, String... strs) {
		if (index < 0 || index >= listaApostador.size()) {
			return false;
		} else {
			if (strs[0].isBlank() || strs[0] != null) {
				listaApostador.get(index).setNombre(strs[0]);
			}
			if (strs[1].isBlank() || strs[1] != null) {
				listaApostador.get(index).setCedula(Long.parseLong(strs[1]));
			}
			if (strs[2].isBlank() || strs[2] != null) {
				listaApostador.get(index).setSede(strs[2]);
			}
			if (strs[3].isBlank() || strs[3] != null) {
				listaApostador.get(index).setDireccion(strs[3]);
			}
			if (strs[4].isBlank() || strs[4] != null) {
				listaApostador.get(index).setNumCelular(Long.parseLong(strs[4]));
			}

			archivoApostador.delete();
			f.crearArchivo();
			f.escribirArchivoApostador(listaApostador);

			return true;
		}
	}

	public void modify(String nombreAModificar, String nuevoNombre, long nuevaCedula, String nuevaSede,
			String nuevaDireccion, long nuevoNumCelular) {
		
		for (int i = 0; i < listaApostador.size(); i++) {
			if(nombreAModificar.equalsIgnoreCase(listaApostador.get(i).getNombre())) {
				listaApostador.set(i, new ApostadorDTO(nuevoNombre, nuevaCedula, nuevaSede, nuevaDireccion, nuevoNumCelular));
			}
		}
		File f1 = new File ("data/apostadores.dat");
		f1.delete();
		f.crearArchivo();
		f.escribirArchivoApostador(listaApostador);
	}

	@Override
	public boolean delete(long idNumber) {
		boolean resp = false;
		for (int i = 0; i < listaApostador.size(); i++) {
			if (idNumber == listaApostador.get(i).getCedula()) {
				listaApostador.remove(i);
				resp = true;
			}
		}
		
		if (resp == true) {
			File f1 = new File ("data/apostadores.dat");
			f1.delete();
			f.crearArchivo();
			f.escribirArchivoApostador(listaApostador);
		}
		return resp;
	}

	@Override
	public boolean delete(Object obj) {
		if (obj == null) {
			return false;
		} else if (listaApostador.remove((ApostadorDTO) obj)) {
			return true;
		} else {
			return false;
		}
	}

	public String initializeFile() {
		listaApostador = f.initializeFile();
		return readAll();
	}

	public ArrayList<ApostadorDTO> getListaApostador() {
		return listaApostador;
	}

	public void setListaApostador(ArrayList<ApostadorDTO> listaApostador) {
		this.listaApostador = listaApostador;
	}

}
