package co.edu.unbosque.model.persistence;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class ArchivoLoteria {
	
	private File fileApuesta;
	private ObjectOutputStream oos;
	
	public ArchivoLoteria() {
		fileApuesta = new File("data/apuestas-loteria.dat");
		
	}


	public void crearArchivo() {
		if(!fileApuesta.exists()) {
		try {
			fileApuesta.createNewFile();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}else {
			System.out.println("El archivo ya existe");
		}
		
	}

	public void escribirArchivo(ArrayList<ApuestaLoteriaDTO> lot) {
		try {
			oos = new ObjectOutputStream(new FileOutputStream(fileApuesta));
			oos.writeObject(lot);
			oos.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	
	public ArrayList<ApuestaLoteriaDTO> inicializarArchivo() {
		
		    ArrayList<ApuestaLoteriaDTO> apuesta = new ArrayList<>();
		    try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fileApuesta))) {
		        Object obj = ois.readObject();
		        apuesta = (ArrayList<ApuestaLoteriaDTO>) obj;
		        System.out.println("Archivo");
		    } catch (FileNotFoundException e) {
		        e.printStackTrace();
		    } catch (IOException | ClassNotFoundException e) {
		        e.printStackTrace();
		    }
		    return apuesta;
		
		
	}

}
