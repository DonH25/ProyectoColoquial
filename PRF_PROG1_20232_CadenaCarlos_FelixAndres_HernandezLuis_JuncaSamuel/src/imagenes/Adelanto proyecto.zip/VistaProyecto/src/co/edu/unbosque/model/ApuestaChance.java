package co.edu.unbosque.model;

import co.edu.unbosque.model.persistence.ApuestaChanceDAO;


public class ApuestaChance {
	private ApuestaChanceDAO apuestaChance;
	
	public ApuestaChance() {
		apuestaChance = new ApuestaChanceDAO();
	}
	
	public void crearApuestaChance(String nombreSede, long cedula, String diaApuesta, double valorApuesta,
			String nombreLoteria, int numeroApostado) {
		apuestaChance.crearApuestaChance(nombreSede, cedula, diaApuesta, valorApuesta, nombreLoteria, numeroApostado);
	}
	
	public void modificarApuestaChance(String nombreSede, long cedula, String diaApuesta, int anteriorNumeroApostado,
			double nuevoValorApuesta, String nuevoNombreLoteria, int nuevoNumeroApostado) {
		apuestaChance.modificarApuestaChance(nombreSede, cedula, diaApuesta, anteriorNumeroApostado, nuevoValorApuesta, nuevoNombreLoteria, nuevoNumeroApostado);;
	}
	
	public String leerApuestaChance () {
		return apuestaChance.leerApuestas();
	}
	
	public void eliminarApuestaChance (long cedula, int numeroApostado) {
		apuestaChance.eliminarApuestaChance(cedula, numeroApostado);
	}
	
	public void inicializarApuestasChance() {
		apuestaChance.inicializarApuestasChance();
	}

	public ApuestaChanceDAO getApuestaChance() {
		return apuestaChance;
	}

	public void setApuestaChance(ApuestaChanceDAO apuestaChance) {
		this.apuestaChance = apuestaChance;
	}
	
	
}
