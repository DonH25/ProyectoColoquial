package co.edu.unbosque.model.persistence;

import java.io.Serializable;

public class SedesDTO implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String ubicacionLocalidad;
	private int numeroDeEmpleados;

	public SedesDTO() {
		// TODO Auto-generated constructor stub
	}

	public SedesDTO(String ubicacionLocalidad, int numeroDeEmpleados) {
		super();
		this.ubicacionLocalidad = ubicacionLocalidad;
		this.numeroDeEmpleados = numeroDeEmpleados;
	}

	public String getUbicacionLocalidad() {
		return ubicacionLocalidad;
	}

	public void setUbicacionLocalidad(String ubicacionLocalidad) {
		this.ubicacionLocalidad = ubicacionLocalidad;
	}

	public int getNumeroDeEmpleados() {
		return numeroDeEmpleados;
	}

	public void setNumeroDeEmpleados(int numeroDeEmpleados) {
		this.numeroDeEmpleados = numeroDeEmpleados;
	}

	@Override
	public String toString() {
		return "--- \n Localidad =" + ubicacionLocalidad + ",\n # empleados ="
				+ numeroDeEmpleados + "\n";
	}
	
	

}
