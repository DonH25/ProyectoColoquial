package co.edu.unbosque.model.persistence;

import java.io.Serializable;

public class GamesDTO implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String name;
	private String gameType;
	private Double gameBudget;
	
	public GamesDTO() {
		// TODO Auto-generated constructor stub
	}

	public GamesDTO(String name, String gameType, Double gameBudget) {
		super();
		this.name = name;
		this.gameType = gameType;
		this.gameBudget = gameBudget;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGameType() {
		return gameType;
	}

	public void setGameType(String gameType) {
		this.gameType = gameType;
	}

	public double getGameBudget() {
		return gameBudget;
	}

	public void setGameBudget(double gameBudget) {
		this.gameBudget = gameBudget;
	}
	
	
	
}
