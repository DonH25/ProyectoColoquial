package co.edu.unbosque.model.persistence;

import java.io.Serializable;

public class ApostadorDTO implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String nombre;
	private long cedula;
	private String sede;
	private String direccion;
	private long numCelular;
	
	public ApostadorDTO() {
	}

	public ApostadorDTO(String nombre, long cedula, String sede, String direccion, long numCelular) {
		super();
		this.nombre = nombre;
		this.cedula = cedula;
		this.sede = sede;
		this.direccion = direccion;
		this.numCelular = numCelular;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public long getCedula() {
		return cedula;
	}

	public void setCedula(long cedula) {
		this.cedula = cedula;
	}

	public String getSede() {
		return sede;
	}

	public void setSede(String sede) {
		this.sede = sede;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public long getNumCelular() {
		return numCelular;
	}

	public void setNumCelular(long numCelular) {
		this.numCelular = numCelular;
	}

	@Override
	public String toString() {
		return "ApostadorDTO [nombre=" + nombre + ", cedula=" + cedula + ", sede=" + sede + ", direccion=" + direccion
				+ ", numCelular=" + numCelular + "]";
	}

}
