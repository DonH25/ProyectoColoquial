package co.edu.unbosque.model.persistence;

import java.io.File;
import java.util.ArrayList;

public class ApuestaChanceDAO {
	private ArrayList<ApuestaChanceDTO> apuestasChance;
	private ArchivoChance archivoChance;

	public ApuestaChanceDAO() {
		apuestasChance = new ArrayList<ApuestaChanceDTO>();
		archivoChance = new ArchivoChance();
	}

	public void crearApuestaChance(String nombreSede, long cedula, String diaApuesta, double valorApuesta,
			String nombreLoteria, int numeroApostado) {

		apuestasChance.add(new ApuestaChanceDTO(nombreSede, cedula, diaApuesta, valorApuesta, nombreLoteria, numeroApostado));
		archivoChance.crearArchivo();
		archivoChance.escribirArchivo(apuestasChance);
		System.out.println("Apuesta realizada correctamente");
	}

	public void modificarApuestaChance(String nombreSede, long cedula, String diaApuesta, int anteriorNumeroApostado,
			double nuevoValorApuesta, String nuevoNombreLoteria, int nuevoNumeroApostado) {

		for (int i = 0; i < apuestasChance.size(); i++) {
			if (cedula == apuestasChance.get(i).getNumCedula()
					&& anteriorNumeroApostado == apuestasChance.get(i).getNumeroApostado()) {
				apuestasChance.set(i, new ApuestaChanceDTO(nombreSede, cedula, diaApuesta, nuevoValorApuesta, nuevoNombreLoteria, nuevoNumeroApostado));
			}
			File tmp = new File("data/apuestas-chance.dat");
			tmp.delete();
			archivoChance.crearArchivo();
			archivoChance.escribirArchivo(apuestasChance);
		}
	}

	public String leerApuestas() {
		String printable = "";
		for (ApuestaChanceDTO apuestaChanceDTO : apuestasChance) {
			printable += apuestaChanceDTO.toString();
		}
		return printable;
	}
	
	public void eliminarApuestaChance(long cedula, int numeroApostado) {
		for (int i = 0; i < apuestasChance.size(); i++) {
			if (cedula == apuestasChance.get(i).getNumCedula()
					&& numeroApostado == apuestasChance.get(i).getNumeroApostado()) {
				apuestasChance.remove(i);
			}
		}
		File tmp = new File("data/apuestas-chance.dat");
		tmp.delete();
		archivoChance.crearArchivo();
		archivoChance.escribirArchivo(apuestasChance);
	}
	
	public void inicializarApuestasChance(){
		apuestasChance = archivoChance.inicializarArchivo();
	}

	public ArrayList<ApuestaChanceDTO> getApuestasChance() {
		return apuestasChance;
	}

	public void setApuestasChance(ArrayList<ApuestaChanceDTO> apuestasChance) {
		this.apuestasChance = apuestasChance;
	}
	
	
}
