package co.edu.unbosque.model;

public class DataException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	public DataException(String msg) {
		super(msg);
	}

}
