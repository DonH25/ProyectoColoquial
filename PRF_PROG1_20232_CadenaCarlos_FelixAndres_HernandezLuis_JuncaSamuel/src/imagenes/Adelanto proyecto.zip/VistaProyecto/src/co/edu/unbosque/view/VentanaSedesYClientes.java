package co.edu.unbosque.view;

import java.awt.Image;
import java.awt.TextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class VentanaSedesYClientes extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JLabel fondo;
	private JButton botonDetalles, botonClienteSedes, botonTotal, botonSedeTipo;

	public VentanaSedesYClientes() {

		setBounds(0, 0, 1080, 700);
		setTitle("Elecciónes");
		setResizable(false);
		setLayout(null);

		fondo = new JLabel();
		fondo.setBounds(0, 0, 1080, 700);
		Image temporal = new ImageIcon("src/images/FondoVR.png").getImage();
		ImageIcon imgResimension = new ImageIcon(
				temporal.getScaledInstance(fondo.getWidth(), fondo.getHeight(), Image.SCALE_SMOOTH));
		fondo.setIcon(imgResimension);

		botonDetalles = new JButton(new ImageIcon("src/images/DetallesBTN.png"));
		botonDetalles.setBounds(185, 95, 290, 180);
		botonDetalles.setOpaque(false);
		botonDetalles.setContentAreaFilled(false);
		botonDetalles.setBorderPainted(false);

		botonClienteSedes = new JButton(new ImageIcon("src/images/ClienteSedes.png"));
		botonClienteSedes.setBounds(595, 95, 290, 180);
		botonClienteSedes.setOpaque(false);
		botonClienteSedes.setContentAreaFilled(false);
		botonClienteSedes.setBorderPainted(false);

		botonTotal = new JButton(new ImageIcon("src/images/TotalApuestasBTN.png"));
		botonTotal.setBounds(185, 350, 290, 180);
		botonTotal.setOpaque(false);
		botonTotal.setContentAreaFilled(false);
		botonTotal.setBorderPainted(false);

		botonSedeTipo = new JButton(new ImageIcon("src/images/SedeYTipoBTN.png"));
		botonSedeTipo.setBounds(595, 350, 290, 180);
		botonSedeTipo.setOpaque(false);
		botonSedeTipo.setContentAreaFilled(false);
		botonSedeTipo.setBorderPainted(false);

		add(botonTotal);
		add(botonSedeTipo);
		add(botonDetalles);
		add(botonClienteSedes);
		add(fondo);
	}

	public JLabel getFondo() {
		return fondo;
	}

	public void setFondo(JLabel fondo) {
		this.fondo = fondo;
	}

	public JButton getBotonDetalles() {
		return botonDetalles;
	}

	public void setBotonDetalles(JButton botonDetalles) {
		this.botonDetalles = botonDetalles;
	}

	public JButton getBotonClienteSedes() {
		return botonClienteSedes;
	}

	public void setBotonClienteSedes(JButton botonClienteSedes) {
		this.botonClienteSedes = botonClienteSedes;
	}

	public JButton getBotonTotal() {
		return botonTotal;
	}

	public void setBotonTotal(JButton botonTotal) {
		this.botonTotal = botonTotal;
	}

	public JButton getBotonSedeTipo() {
		return botonSedeTipo;
	}

	public void setBotonSedeTipo(JButton botonSedeTipo) {
		this.botonSedeTipo = botonSedeTipo;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	
	
}