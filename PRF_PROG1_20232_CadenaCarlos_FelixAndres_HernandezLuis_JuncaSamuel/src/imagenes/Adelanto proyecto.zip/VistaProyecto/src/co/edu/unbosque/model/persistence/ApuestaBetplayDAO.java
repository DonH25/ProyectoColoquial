package co.edu.unbosque.model.persistence;

import java.io.File;
import java.util.ArrayList;

public class ApuestaBetplayDAO {
	private ArrayList<ApuestaBetplayDTO> apuestaBetplay;
	private ArchivoBetplay archivoBetplay;

	public ApuestaBetplayDAO() {
		apuestaBetplay = new ArrayList<ApuestaBetplayDTO>();
		archivoBetplay = new ArchivoBetplay();
	}

	public String crearApuestaBetplay(String nombreSede, long cedula, String diaApuesta, double valorApuesta,
			String partido1, String partido2, String partido3, String partido4, String partido5, String partido6,
			String partido7, String partido8, String partido9, String partido10, String partido11, String partido12,
			String partido13, String partido14) {
		String salida = null;
		if (!partido1.equalsIgnoreCase(null) && !partido2.equalsIgnoreCase(null) && !partido3.equalsIgnoreCase(null)
				&& !partido4.equalsIgnoreCase(null) && !partido5.equalsIgnoreCase(null)
				&& !partido6.equalsIgnoreCase(null) && !partido7.equalsIgnoreCase(null)
				&& !partido8.equalsIgnoreCase(null) && !partido9.equalsIgnoreCase(null)
				&& !partido10.equalsIgnoreCase(null) && !partido11.equalsIgnoreCase(null)
				&& !partido12.equalsIgnoreCase(null) && !partido13.equalsIgnoreCase(null)
				&& !partido14.equalsIgnoreCase(null)) {

			archivoBetplay.crearArchivo();
			apuestaBetplay.add(new ApuestaBetplayDTO(nombreSede, cedula, diaApuesta, valorApuesta, partido1, partido2,
					partido3, partido4, partido5, partido6, partido7, partido8, partido9, partido10, partido11,
					partido12, partido13, partido14));
			archivoBetplay.escribirArchivo(apuestaBetplay);
			salida = "Apuesta realizada correctamente";
		} else {
			salida = "Debe llenar los resultados de todos los partidos";
		}
		return salida;
	}

	public String modificarApuestaBetplay(String nombreSede, long cedula,String diaApuestaAnterior, String diaApuesta, double valorApuesta,
			String partido1, String partido2, String partido3, String partido4, String partido5, String partido6,
			String partido7, String partido8, String partido9, String partido10, String partido11, String partido12,
			String partido13, String partido14) {

		String salida = null;
		if (!partido1.equalsIgnoreCase(null) && !partido2.equalsIgnoreCase(null) && !partido3.equalsIgnoreCase(null)
				&& !partido4.equalsIgnoreCase(null) && !partido5.equalsIgnoreCase(null)
				&& !partido6.equalsIgnoreCase(null) && !partido7.equalsIgnoreCase(null)
				&& !partido8.equalsIgnoreCase(null) && !partido9.equalsIgnoreCase(null)
				&& !partido10.equalsIgnoreCase(null) && !partido11.equalsIgnoreCase(null)
				&& !partido12.equalsIgnoreCase(null) && !partido13.equalsIgnoreCase(null)
				&& !partido14.equalsIgnoreCase(null)) {
			for (int i = 0; i < apuestaBetplay.size(); i++) {
				if (cedula == apuestaBetplay.get(i).getNumCedula()
						&& diaApuesta.equalsIgnoreCase(apuestaBetplay.get(i).getDiaApuesta())) {

					apuestaBetplay.set(i,
							new ApuestaBetplayDTO(nombreSede, cedula, diaApuesta, valorApuesta, partido1, partido2,
									partido3, partido4, partido5, partido6, partido7, partido8, partido9, partido10,
									partido11, partido12, partido13, partido14));

				}
			}
			File f = new File("data/apuestas-betplay.dat");
			f.delete();
			archivoBetplay.crearArchivo();
			archivoBetplay.escribirArchivo(apuestaBetplay);
			salida = "Apuesta modificada correctamente";
		} else {
			salida = "Debe llenar todos los partidos";
		}
		return salida;
	}

	public String leerApuestas() {
		String printable = "";
		for (ApuestaBetplayDTO apuestaBetplayDTO : apuestaBetplay) {
			printable += apuestaBetplayDTO.toString();
		}
		return printable;
	}

	public String eliminarApuestaBetplay(long cedula, String diaApuesta) {
		boolean temp = true;
		String salida = null;
		for (int i = 0; i < apuestaBetplay.size(); i++) {
			if ( cedula == apuestaBetplay.get(i).getNumCedula()
					&& diaApuesta.equalsIgnoreCase(apuestaBetplay.get(i).getDiaApuesta())) {

				apuestaBetplay.remove(i);
				File f = new File("data/apuestas-betplay.dat");
				f.delete();
				archivoBetplay.crearArchivo();
				archivoBetplay.escribirArchivo(apuestaBetplay);
				temp = true;

			} else {
				temp = false;
			}

			if (temp == true) {
				salida = "Apuesta eliminada exitosamente";
			}
		}
		return salida;
	}

	public void inicializarApuestasBetplay() {
		apuestaBetplay = archivoBetplay.inicializarArchivo();
	}

	public ArrayList<ApuestaBetplayDTO> getApuestaBetplay() {
		return apuestaBetplay;
	}

	public void setApuestaBetplay(ArrayList<ApuestaBetplayDTO> apuestaBetplay) {
		this.apuestaBetplay = apuestaBetplay;
	}

}
