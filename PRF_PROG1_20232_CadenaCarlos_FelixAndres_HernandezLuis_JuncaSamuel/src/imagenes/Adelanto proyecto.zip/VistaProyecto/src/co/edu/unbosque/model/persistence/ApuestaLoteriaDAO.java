package co.edu.unbosque.model.persistence;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class ApuestaLoteriaDAO {
	private ArrayList<ApuestaLoteriaDTO> apuestasLoteria;
	private ArchivoLoteria archivoLoteria;

	public ApuestaLoteriaDAO() {
		apuestasLoteria = new ArrayList<ApuestaLoteriaDTO>();
		archivoLoteria = new ArchivoLoteria();
	}

	public void crearApuestaLoteria(String nombreSede, long cedula, String diaApuesta, double valorApuesta,
			String nombreLoteria, int numeroApostado, int numeroSerie) {

		apuestasLoteria.add(new ApuestaLoteriaDTO(nombreSede, cedula, diaApuesta, valorApuesta, nombreLoteria,
				numeroApostado, numeroSerie));
		archivoLoteria.crearArchivo();
		archivoLoteria.escribirArchivo(apuestasLoteria);
		System.out.println("Apuesta realizada correctamente");
	}
	
	public String leerApuestas() {
		inicializarApuestasLoteria();
		String printable = "";
		for (ApuestaLoteriaDTO apuestaLoteria : apuestasLoteria) {
			printable += apuestaLoteria.toString();
		}
		return printable;
	}

	public void modificarApuestaLoteria(String nombreSede, long cedula, String diaApuesta, int anteriorNumeroApostado,
			double nuevoValorApuesta, String nuevoNombreLoteria, int nuevoNumeroApostado, int nuevoNumeroSerie) {

		for (int i = 0; i < apuestasLoteria.size(); i++) {
			if (cedula == apuestasLoteria.get(i).getNumCedula()
					&& anteriorNumeroApostado == apuestasLoteria.get(i).getNumeroApostado()) {
				apuestasLoteria.set(i, new ApuestaLoteriaDTO(nombreSede, cedula, diaApuesta, nuevoValorApuesta,
						nuevoNombreLoteria, nuevoNumeroApostado, nuevoNumeroSerie));
			}
			File tmp = new File("data/apuestas-loteria.dat");
			tmp.delete();
			archivoLoteria.crearArchivo();
			archivoLoteria.escribirArchivo(apuestasLoteria);
		}
	}


	
		
	
	public void eliminarApuestaLoteria(long cedula, int numeroApostado) {
		for (int i = 0; i < apuestasLoteria.size(); i++) {
			if (cedula == apuestasLoteria.get(i).getNumCedula()
					&& numeroApostado == apuestasLoteria.get(i).getNumeroApostado()) {
				apuestasLoteria.remove(i);
			}
		}
		File tmp = new File("data/apuestas-loteria.dat");
		tmp.delete();
		archivoLoteria.crearArchivo();
		archivoLoteria.escribirArchivo(apuestasLoteria);
	}
	
	public void inicializarApuestasLoteria(){
		apuestasLoteria = archivoLoteria.inicializarArchivo();
	}

	public ArrayList<ApuestaLoteriaDTO> getApuestasLoteria() {
		return apuestasLoteria;
	}

	public void setApuestasLoteria(ArrayList<ApuestaLoteriaDTO> apuestasLoteria) {
		this.apuestasLoteria = apuestasLoteria;
	}
	
	
}
