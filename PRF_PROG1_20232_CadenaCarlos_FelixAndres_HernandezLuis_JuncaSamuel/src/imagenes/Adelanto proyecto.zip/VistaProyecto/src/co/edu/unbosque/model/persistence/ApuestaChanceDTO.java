package co.edu.unbosque.model.persistence;

import java.io.Serializable;

public class ApuestaChanceDTO extends Apuesta implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String nombreLoteria;
	private int numeroApostado;
	public ApuestaChanceDTO(String nombreSede, long numCedula, String diaApuesta, double valorApuesta) {
		super(nombreSede, numCedula, diaApuesta, valorApuesta);
		// TODO Auto-generated constructor stub
	}
	public ApuestaChanceDTO(String nombreSede, long numCedula, String diaApuesta, double valorApuesta, String nombreLoteria,
			int numeroApostado) {
		super(nombreSede, numCedula, diaApuesta, valorApuesta);
		this.nombreLoteria = nombreLoteria;
		this.numeroApostado = numeroApostado;
	}
	
	public String toString() {
		return "Apuesta Superastro: "+"\n" + "Nombre sede: " + nombreSede + " Cedula: " + numCedula + " Dia apuesta: "
				+ diaApuesta + " Valor apuesta: " + valorApuesta + " Nombre Loteria: " + nombreLoteria
				+" Número apostado: "+numeroApostado+"\n";
	}
	public String getNombreLoteria() {
		return nombreLoteria;
	}
	public void setNombreLoteria(String nombreLoteria) {
		this.nombreLoteria = nombreLoteria;
	}
	public int getNumeroApostado() {
		return numeroApostado;
	}
	public void setNumeroApostado(int numeroApostado) {
		this.numeroApostado = numeroApostado;
	}
	public String getNombreSede() {
		return nombreSede;
	}

	public void setNombreSede(String nombreSede) {
		this.nombreSede = nombreSede;
	}

	public long getNumCedula() {
		return numCedula;
	}

	public void setNumCedula(long numCedula) {
		this.numCedula = numCedula;
	}

	public String getDiaApuesta() {
		return diaApuesta;
	}

	public void setDiaApuesta(String diaApuesta) {
		this.diaApuesta = diaApuesta;
	}

	public double getValorApuesta() {
		return valorApuesta;
	}

	public void setValorApuesta(double valorApuesta) {
		this.valorApuesta = valorApuesta;
	}
	
}
