package co.edu.unbosque.model;

import co.edu.unbosque.model.persistence.ApuestaLoteriaDAO;

public class ApuestaLoteria {
	private ApuestaLoteriaDAO apuestaLoteria;
	
	public ApuestaLoteria() {
		apuestaLoteria = new ApuestaLoteriaDAO();
	}
	
	public void crearApuestaLoteria(String nombreSede, long cedula, String diaApuesta, double valorApuesta,
			String nombreLoteria, int numeroApostado, int numeroSerie) {
		apuestaLoteria.crearApuestaLoteria(nombreSede, cedula, diaApuesta, valorApuesta, nombreLoteria, numeroApostado, numeroSerie);
	}
	
	public void modificarApuestaLoteria(String nombreSede, long cedula, String diaApuesta, int anteriorNumeroApostado,
			double nuevoValorApuesta, String nuevoNombreLoteria, int nuevoNumeroApostado, int nuevoNumeroSerie) {
		apuestaLoteria.modificarApuestaLoteria(nombreSede, cedula, diaApuesta, anteriorNumeroApostado, nuevoValorApuesta, nuevoNombreLoteria, nuevoNumeroApostado, nuevoNumeroSerie);
	}
	
	public String leerApuestaLoteria() {
		return apuestaLoteria.leerApuestas();
	}
	
	public void eliminarApuestaLoteria(long cedula,int numeroApostado) {
		apuestaLoteria.eliminarApuestaLoteria(cedula, numeroApostado);;
	}
	
	public void inicializarApuestasLoteria () {
		apuestaLoteria.inicializarApuestasLoteria();
	}

	public ApuestaLoteriaDAO getApuestaLoteria() {
		return apuestaLoteria;
	}

	public void setApuestaLoteria(ApuestaLoteriaDAO apuestaLoteria) {
		this.apuestaLoteria = apuestaLoteria;
	}
	
	
	
}
