package co.edu.unbosque.model.persistence;

import java.io.Serializable;

public class BettingHouseDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String bettingHouseName;
	private int numberOfSites;
	private double totalBudget;
	
	public BettingHouseDTO() {
		verifyInvariant();
	}

	public BettingHouseDTO(String bettingHouseName, int numberOfSites, double totalBudget) {
		super();
		this.bettingHouseName = bettingHouseName;
		this.numberOfSites = numberOfSites;
		this.totalBudget = totalBudget;
	}

	public String getBettingHouseName() {
		return bettingHouseName;
	}

	public void setBettingHouseName(String bettingHouseName) {
		this.bettingHouseName = bettingHouseName;
	}

	public int getNumberOfSites() {
		return numberOfSites;
	}

	public void setNumberOfSites(int numberOfSites) {
		this.numberOfSites = numberOfSites;
	}

	public double getTotalBudget() {
		return totalBudget;
	}

	public void setTotalBudget(double totalBudget) {
		this.totalBudget = totalBudget;
	}
	
	private void verifyInvariant() {
		assert bettingHouseName != null: "El nombre no puede estar vacio";
        assert numberOfSites>0: "El número de sedes no puede ser menor o igual a 0";
        assert totalBudget>0: "El presupuesto total no puede ser menor o igual a 0";
	}




}
