package co.edu.unbosque.model.persistence;

import java.io.File;
import java.util.ArrayList;

public class GamesDAO {

	private ArrayList<GamesDTO> games;
	private GamesFile gFile;
	private BettingHouseDAO bHouse;
	private Double budgetSum;

	public GamesDAO() {
		budgetSum = 0.0;
		games = new ArrayList<GamesDTO>();
		gFile = new GamesFile();
		bHouse = new BettingHouseDAO();

	}

	public void createGames(String name, String gameType, String gameBudget) {

		games.add(new GamesDTO(name, gameType, Double.parseDouble(gameBudget)));
		if (games.size() == 5) {

			gFile.createFile();
			File f = new File("data/juegos.dat");
			gFile.writeFile(games, f);
		}

	}

	public void modifyGames(String name, String gameType, String newBudget, int pos) {
		int adition = 0;
		games.set(pos, new GamesDTO(name, gameType, Double.parseDouble(newBudget)));
		adition = adition++;
		
			File f = new File ("data/juegos.dat");
			f.delete();
			gFile.createFile();
			gFile.writeFile(games, f);
			System.out.println(games);
		
		
	}
	
	

	public void initializeGames() {
		games = gFile.initializeFile();

	}

	public ArrayList<GamesDTO> getGames() {
		return games;
	}

	public void setGames(ArrayList<GamesDTO> games) {
		this.games = games;
	}
	
	

}
