package co.edu.unbosque.model.persistence;

import java.io.File;
import java.util.ArrayList;

public class SedesDAO {

	private ArrayList<SedesDTO> sedes;
	private ArchivoSedes archivoSedes;
	
	public SedesDAO() {
		archivoSedes = new ArchivoSedes();
		sedes = new ArrayList<SedesDTO>();
	}
	
	public String crearSede(int cantidadSedes, String localidad, int cantidadEmpleados) {
		sedes.add(new SedesDTO(localidad, cantidadEmpleados));
		String confirmacion = "";
		if (sedes.size()==cantidadSedes) {
			archivoSedes.crearArchivo();
			archivoSedes.escribirArchivoSedes(sedes);
			System.out.println(sedes);
			confirmacion = "Archivo de sedes creado exitosamente";
		}else {
			confirmacion = "Aun no has gestionado todas las sedes.";
		}
		
		return confirmacion;
	}
	
	public void modificarSede (String localidadAnt, String localidadNueva, int numEmpleadosNuevo) {
		for (int i = 0; i < sedes.size();i++) {
			if (sedes.get(i).getUbicacionLocalidad().equalsIgnoreCase(localidadAnt)) {
				sedes.set(i, new SedesDTO(localidadNueva, numEmpleadosNuevo));
				System.out.println(sedes.get(i));
				File tmp = new File("data/sedes.dat");
				tmp.delete();
				archivoSedes.crearArchivo();
				archivoSedes.escribirArchivoSedes(sedes);
			}else {
				System.out.println("Sede no encontrada.");
			}
		}
	}
	
	public String leerSedes() {
		String sedesDisponibles = "";
		for (int i = 0; i<sedes.size(); i++) {
			sedesDisponibles = sedesDisponibles.concat("\n"+sedes.get(i).getUbicacionLocalidad());
		}
		return sedesDisponibles;
	}
	
	public String eliminarSedes (String localidad, int cantidadSedes) {
		String confirmacion = null;
		SedesDTO encontrado = null;
		for (int i = 0; i<sedes.size(); i++) {
			if (localidad.equalsIgnoreCase(sedes.get(i).getUbicacionLocalidad())) {
				encontrado = sedes.get(i);
			}
		}
		sedes.remove(encontrado);
		if (sedes.size()==cantidadSedes) {
			confirmacion = "Sedes gestionadas correctamente";
			File archivo = new File("data/sedes.dat");
			archivo.delete();
			archivoSedes.crearArchivo();
			archivoSedes.escribirArchivoSedes(sedes);
		}else {
			confirmacion = "Aun no ha gestionado todas las sedes, debe seguir eliminando sedes hasta igualar el número de sedes ingresado anteriormente.";
		}
		return confirmacion;
		
		
	}
	
	public void inicializarSedes () {
		sedes = archivoSedes.initializeFile();
		System.out.println(archivoSedes.initializeFile());
	}

	public ArrayList<SedesDTO> getSedes() {
		return sedes;
	}

	public void setSedes(ArrayList<SedesDTO> sedes) {
		this.sedes = sedes;
	}
	
	
}
