package co.edu.unbosque.model;

import co.edu.unbosque.model.persistence.ApuestaBalotoDAO;

public class ApuestaBaloto {

	private ApuestaBalotoDAO apuestaBaloto;

	public ApuestaBaloto() {

		apuestaBaloto = new ApuestaBalotoDAO();
	}

	public String crearApuestaBaloto(String nombreSede, long cedula, String diaApuesta, double valorApuesta,
			String numApostado) {
		return apuestaBaloto.crearApuestaBaloto(nombreSede, cedula, diaApuesta, valorApuesta, numApostado);
	}

	public String modificarApuestaBaloto(String nombreSede, long cedula, String diaApuesta, double valorApuesta,
			String numApostado, String nuevoNumApostado) {
		return apuestaBaloto.modificarApuestaBaloto(nombreSede, cedula, diaApuesta, valorApuesta, numApostado,
				nuevoNumApostado);
	}

	public String leerApuestaBaloto() {
		return apuestaBaloto.leerApuestas();
	}

	public void eliminarApuestaBaloto(long cedula, String numeroApostado) {
		apuestaBaloto.eliminarApuestaBaloto(cedula, numeroApostado);
	}
	
	public void inicializarApuestasBaloto () {
		apuestaBaloto.inicializarArchivo();
	}

	public ApuestaBalotoDAO getApuestaBaloto() {
		return apuestaBaloto;
	}

	public void setApuestaBaloto(ApuestaBalotoDAO apuestaBaloto) {
		this.apuestaBaloto = apuestaBaloto;
	}
	
	
}
