package co.edu.unbosque.model.persistence;

public class BettingHouseDAO {
	
	private BettingHouseDTO bettingHouse;
	private BHProperties data;
	
	
	public BettingHouseDAO() {
	bettingHouse = new BettingHouseDTO();
	data = new BHProperties();
	}
	
	public void createBettingHouse (String houseName, String numberOfSites, String totalBudget) {
		data.writeProperties(houseName, numberOfSites, totalBudget);
		bettingHouse = new BettingHouseDTO(houseName, Integer.parseInt(numberOfSites), Double.parseDouble(totalBudget));
	}
	
	public void modifyBettingHouse (String newHouseName, String newNumberOfSites, String newTotalBudget) {
		bettingHouse.setBettingHouseName(newHouseName);
		bettingHouse.setNumberOfSites(Integer.parseInt(newNumberOfSites));
		bettingHouse.setTotalBudget(Double.parseDouble(newTotalBudget));
		data.modifyProperties(newHouseName, newNumberOfSites, newTotalBudget);
	}

	public void initializeBettingHouse () {
		
		data.initializeProperties();
		bettingHouse.setBettingHouseName(data.getBettingHouseName());
		bettingHouse.setNumberOfSites(Integer.parseInt(data.getNumberOfSites()));
		bettingHouse.setTotalBudget(Double.parseDouble(data.getTotalBudget()));
		
		
		
	}

	public BettingHouseDTO getBettingHouse() {
		return bettingHouse;
	}

	public void setBettingHouse(BettingHouseDTO bettingHouse) {
		this.bettingHouse = bettingHouse;
	}
	
	
}
