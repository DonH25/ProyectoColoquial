package co.edu.unbosque.model;

import co.edu.unbosque.model.persistence.SedesDAO;

public class GestionSedes {
	private SedesDAO sedes;
	
	public GestionSedes() {
		sedes = new SedesDAO();
	}
	
	public String crearNuevaSede (int cantidadSedes, String localidad, int numEmpleados) {
		return sedes.crearSede(cantidadSedes, localidad, numEmpleados);
	}
	
	public void modificarSede (String localidadAnt, String localidadNueva, int numEmpleadosNuevo) {
		sedes.modificarSede(localidadAnt, localidadNueva, numEmpleadosNuevo);
	}
	
	public String eliminarSede (int cantidadSedes, String localidadAEliminar) {
		return sedes.eliminarSedes(localidadAEliminar, cantidadSedes);
	}
	
	public void inicializarSedes() {
		sedes.inicializarSedes();
	}
	
	public String mostrarSedes() {
		return sedes.leerSedes();
	}

	public SedesDAO getSedes() {
		return sedes;
	}

	public void setSedes(SedesDAO sedes) {
		this.sedes = sedes;
	}
	
	
}
