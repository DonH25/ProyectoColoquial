package co.edu.unbosque.model;

import co.edu.unbosque.model.persistence.BettingHouseDAO;

public class BettingHouse {
	private BettingHouseDAO house;
	
	public BettingHouse() {
		house = new BettingHouseDAO();
	}
	
	public void fillBettingHouseData(String name, String sites, String budget) {
		house.createBettingHouse(name, sites, budget);
	}
	
	public void initializeBettingHouseData() {
		house.initializeBettingHouse();
	}
	
	public void modifyBettingHouseData(String name, String sites, String budget) {
		house.modifyBettingHouse(name, sites, budget);
	}
	

	public BettingHouseDAO getHouse() {
		return house;
	}

	public void setHouse(BettingHouseDAO house) {
		this.house = house;
	}
	
	
	
}
